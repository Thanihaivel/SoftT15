README.txt

The dll paths must be mentioned in MyVBFrameworkApp.vbproj

In Program.vb and base.html, the IP and the Port must be changed according to the user's pc.


