import pefile
import sys
import os

def list_exports(dll_path):
    if not os.path.exists(dll_path):
        print(f"❌ File not found: {dll_path}")
        return

    try:
        pe = pefile.PE(dll_path)
        print(f"📦 Exported functions in: {dll_path}")
        if hasattr(pe, 'DIRECTORY_ENTRY_EXPORT'):
            for symbol in pe.DIRECTORY_ENTRY_EXPORT.symbols:
                name = symbol.name.decode('utf-8') if symbol.name else f"<ordinal {symbol.ordinal}>"
                print(f"  - {name}")
        else:
            print("⚠️  No export table found in this DLL.")
    except Exception as e:
        print(f"❌ Failed to parse {dll_path}: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python dll_export_viewer.py <path_to_dll>")
    else:
        list_exports(sys.argv[1])
