Imports System
Imports System.Net
Imports CATS
Imports CATS_API

Module Program
    ' Initial relay state (0 = off, 1 = on)
    Dim relayState As Integer = 0
    Dim cats As New CATS.CATS()
    Dim catsApi As New CATS_API.CATS_API()

    Sub Main()
        Try
            ' Initialize USB and device connection
            Dim tokenGuid As Guid = Guid.Parse("6E45736A-2B1B-4078-B772-B3AF2B6FDE1C")
            Dim usbManager As New WinUsbNet.WinUsbManager(tokenGuid)
            Dim usbDevices = usbManager.UsbDevices
            Console.WriteLine($"Found {usbDevices.Count} USB device(s)")

            ' Connect to the device once
            Dim result As Integer = cats.DeviceConnect()
            Console.WriteLine("DeviceConnect : " & result)

            ' Only proceed if device is connected
            If result = 0 Then
                Console.WriteLine("Device connected successfully.")
                StartServer()
            Else
                Console.WriteLine("DeviceConnect failed, unable to start server.")
            End If

        Catch ex As Exception
            Console.WriteLine("An error occurred: " & ex.Message)
        End Try
    End Sub

    ' Start the HTTP server
    Sub StartServer()
        Dim listener As New HttpListener()
        listener.Prefixes.Add("http://10.164.151.195:9000/") ' Bind the listener to this IP and port
        listener.Start()
        Console.WriteLine("Server started at http://10.164.151.195:9000/")

        While True
            Dim context As HttpListenerContext = listener.GetContext()
            Dim request As HttpListenerRequest = context.Request
            Dim response As HttpListenerResponse = context.Response

            ' Serve the HTML page when accessing the root URL "/"
            If request.RawUrl = "/" Then
                ' Serve the HTML page with button
                Dim html As String = "<!DOCTYPE html>
                    <html lang='en'>
                    <head>
                        <meta charset='UTF-8'>
                        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                        <title>Relay Controller</title>
                        <style>
                            body { font-family: Arial, sans-serif; padding: 20px; }
                            #toggleButton { padding: 10px 20px; font-size: 16px; cursor: pointer; border: none; border-radius: 5px; color: white; }
                            .on { background-color: green; }
                            .off { background-color: red; }
                        </style>
                    </head>
                    <body>
                        <h1>Relay Controller</h1>
                        <button id='toggleButton' class='" & If(relayState = 1, "on", "off") & "' onclick='toggleRelay()'>" & If(relayState = 1, "On", "Off") & "</button>
                        <script>
                            function toggleRelay() {
                                fetch('http://10.164.151.195:9000/toggle')
                                    .then(response => response.json())
                                    .then(data => {
                                        let button = document.getElementById('toggleButton');
                                        // Update button text and color based on new state
                                        if (data.state === 1) {
                                            button.innerHTML = 'On';
                                            button.classList.remove('off');
                                            button.classList.add('on');
                                        } else {
                                            button.innerHTML = 'Off';
                                            button.classList.remove('on');
                                            button.classList.add('off');
                                        }
                                        alert('Relay toggled!');
                                    })
                                    .catch(error => alert('Error: ' + error));
                            }
                        </script>
                    </body>
                    </html>"

                ' Return the HTML content as the response
                Dim buffer As Byte() = System.Text.Encoding.UTF8.GetBytes(html)
                response.ContentLength64 = buffer.Length
                response.OutputStream.Write(buffer, 0, buffer.Length)
            End If

            ' Handle /toggle endpoint to toggle the relay
            If request.RawUrl = "/toggle" Then
                ' Check the current relay state and toggle it
                If relayState = 0 Then
                    cats.SetRelay(0, 1)  ' Turn on the relay
                    relayState = 1       ' Update the relay state to 'on'
                    Console.WriteLine("Relay turned ON")
                Else
                    cats.SetRelay(1, 0)  ' Turn off the relay
                    relayState = 0       ' Update the relay state to 'off'
                    Console.WriteLine("Relay turned OFF")
                End If

                ' Return the current state of the relay (1 = on, 0 = off)
                response.ContentType = "application/json"
                Dim responseJson As String = $"{{ ""state"": {relayState} }}"
                Dim buffer As Byte() = System.Text.Encoding.UTF8.GetBytes(responseJson)
                response.ContentLength64 = buffer.Length
                response.OutputStream.Write(buffer, 0, buffer.Length)
            End If

            response.OutputStream.Close()
        End While
    End Sub
End Module
