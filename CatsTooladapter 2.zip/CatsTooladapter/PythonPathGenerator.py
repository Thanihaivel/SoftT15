﻿import sys
import os
class PythonPathGenerator(object):
    def __AddPathToSysPath__(self,path):
        if not (path in str(sys.path)):
           sys.path.append(path)
    def GeneratePythonPath(self):
        currentWorkingDirectory = os.getcwd()
        mainPath = currentWorkingDirectory[:currentWorkingDirectory.rfind('\\Utilities')]
        self.__AddPathToSysPath__(mainPath+"\\UserPyModules")
        self.__AddPathToSysPath__(mainPath+"\\Utilities")
  
 