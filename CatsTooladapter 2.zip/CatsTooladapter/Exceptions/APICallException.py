﻿class APICallException(Exception):
    pass