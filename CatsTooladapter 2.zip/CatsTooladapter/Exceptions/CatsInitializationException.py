﻿class CatsInitializationException(Exception):
    pass


