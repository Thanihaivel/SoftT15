# -*- coding: ISO-8859-1 -*-

"""
CatsToolAdapter
===============
This user implemented ToolAdapter for ECU-TEST can be used for accessing a Bosch CATS V2.0 via USB.

Access to the device is enabled by the provided CATS.dll, whose methods are imported using
the python module clr (see U{http://pythonnet.sourceforge.net/readme.html}). For USB communication
the WinUsbNet.dll is necessary (see U{https://winusbnet.codeplex.com/}).

Implementing new methods
------------------------
B{Important note:}

Any change to the L{CatsToolAdapter} definition requires the following steps to make the changes
take effect:
    1. A restart of ECU-TEST,
    2. An update of the tool list in the testbench configuration file.

Several CATS API methods are already routed through this ToolAdapter as ToolJobs
(see L{CatsToolAdapter}).
The ToolJob names are identical to those of the corresponding API methods.
Missing methods can be added.

Adding new API methods as ToolJobs has to be done slightly differently when adding methods that
manipulate the devices ("setters") or methods that retrieve data from the device ("getters").

Adding setter methods
~~~~~~~~~~~~~~~~~~~~~
The parameter signatures of new "setter" ToolJobs are identical to those of the API methods.
They can be added by following these steps:
    1. In L{CatsToolAdapter.__init__()} add an instance of JobDescriptor() that defines the
       method name, parameters, and the return value.

       Example:

       >>> JobDescriptor(u"SetAnotherValue",
                        [
                            PropertyDescriptor.CreateInstance(
                                name=u"param1",
                                displayName=u"param1",
                                description=u"Parameter description",
                                type=PropertyTypeId.int,
                                default=0
                            )
                         ],
                         u"Description of SetAnotherValue",
                         PropertyDescriptor.CreateInstance(
                             name=u"result",
                             description=u"Return value (0 if successful)",
                             type=PropertyTypeId.int),
                      )

    2. Add a class method in L{CatsToolAdapter} that calls the corresponding API method.
       The method name must be preceded by "Job". This call returns a return code (0 if successful)

       Example:

       >>> def JobSetAnotherValue(self, param1):
               self._VerifyCatsInitialized()
               return self.cats.SetAnotherValue(param1)

Adding getter methods
~~~~~~~~~~~~~~~~~~~~~
The parameter signatures of new "getter" ToolJobs differ from those of the corresponding API method,
because the API call uses a "by reference"/"out" parameter for returning the retrieved value,
whereas PortJobs only support return values.

New "getter" methods can be added by following these steps:
    1. In L{CatsToolAdapter.__init__()} add an instance of JobDescriptor() that defines the
       method name, parameters, and the return value. The "out" parameter of the API call
       (usually the last one that is indicated by an *) must be omitted in the parameter definition.
       Instead, it has to be added as return value of the JobDescriptor.

       Example:

       >>> JobDescriptor(u"GetAnotherValue",
                        [
                            PropertyDescriptor.CreateInstance(
                                name=u"param1",
                                displayName=u"param1",
                                description=u"Parameter description",
                                type=PropertyTypeId.int,
                                default=0
                            )
                         ],
                         u"Description of GetAnotherValue",
                         PropertyDescriptor.CreateInstance(
                             name=u"anotherValue",
                             description=u"Another value, retrieved from the device",
                             type=PropertyTypeId.int),
                      )

    2. Add a class method in L{CatsToolAdapter} that calls the corresponding API method.
       The method name must be preceded by "Job". In the API call, the value of the "out" parameter
       must be set to an arbitrary value of the same time type. The API call returns a tuple
       of two elements, where the first is a return code (a value of 0 means success) and
       the second element is the desired data.

       Example:

       >>> def JobGetAnotherValue(self, param1):
               self._VerifyCatsInitialized()
               result = self.cats.GetAnotherValue(param1, 0)
               return result[1]
"""
import os
import sys
import types
import clr

from abc import ABCMeta, abstractmethod
from System import Double, Decimal
from lib.common.Properties import PropertyTypeId
from lib.tooling.Capabilities import Toolcaps
from lib.tooling.Descriptors import ToolDescriptor, PropertyDescriptor, JobDescriptor
from lib.tooling.toolLibs.base.AbstractAdapter import ToolAdapter
from lib.tooling.toolLibs.base.Exceptions import ToollibError
from lib.tooling.toolLibs.base.Proxy import ToolAdapterProxy
from user.PLib.System.Logger import Logger, LogLevel
from .CatsTooladapter.CATS22.CatsAPIHandler22 import *
from .CatsTooladapter.CATS20.CatsAPIHandler20 import *
from .CatsTooladapter.Exceptions.APICallException  import APICallException

__docformat__ = "epytext en"

TOOLNAME = u"CATS"
TOOLCAPS = Toolcaps.GetNull()

def IsInstalled():
    return True

def CreateToolAdapter(host=None, port=None):
    return ToolAdapterProxy(CatsToolAdapter())

class CatsTooladapterException(Exception):
    pass

class CatsTooladapterException(Exception):
    pass

class CatsToolAdapter(ToolAdapter):
    __className__ = "CatsToolAdapter"
    CatsdllsLoaded = False
    CatsInterfaceTuple = None

    def __GenerateCommonTooljobs__(self):
        jobDescriptors = [
                             JobDescriptor(u"ConnectDevice",
                                [],
                                 u"Connect to CATS device",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object ),
                              ),
                             JobDescriptor(u"DisconnectDevice",
                                [],
                                 u"Disconnect from CATS device",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object ),
                              ),
                             JobDescriptor(u"IsDeviceConnected",
                                [],
                                 u"Returns if CATS is connected or not.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object ),
                              ),
                              JobDescriptor(u"SetDigitalOutputStatus",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the Digital output channel, "
                                        u"according to connector panel labelling (0-3)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"status",
                                        displayName=u"status",
                                        description=u"Digital Output On-Off Status (0-Off, 1-On)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Sets the digital output channel to ON or OFF ",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"ConfigureDigitalOutputVoltage",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"referenceVoltageSelector",
                                        displayName=u"referenceVoltageSelector",
                                        description=u"Identfier for voltage selection "
                                        u"(0 = 5 Volts, 1 = 12 Volts)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"configures the digital output voltage  to 0 = 5V 1 = 12V)",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object )
                              ),
                              JobDescriptor(u"ConfigureDigitalInputChannel",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the Digital input channel, "
                                        u"according to connector panel labelling (0-3)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"referenceVoltageSelector",
                                        displayName=u"referenceVoltageSelector",
                                        description=u"Identfier for voltage selection"
                                        u"(0 = 12 Volts, 1 = VRef, 2 = Pull-Down)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"configures the digital input reference voltage to 0 = 12 Volts, 1 = VRef, 2 = Pull-Down)",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object )
                              ),
                              JobDescriptor(u"ConfigureAllDigitalInputChannels",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"referenceVoltageSelector",
                                        displayName=u"referenceVoltageSelector",
                                        description=u"Identfier for voltage selection"
                                        u"(0 = 12 Volts, 1 = VRef, 2 = Pull-Down)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"configures the digital input reference voltage to 0 = 12 Volts, 1 = VRef, 2 = Pull-Down)",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object )
                              ),
                              JobDescriptor(u"GetDigitalInputChannel",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the Digital input channel, "
                                        u"according to connector panel labelling (0-3)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Gets the logical value 0 or 1 of the signal applied to the given channel",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object )
                              ),
                              JobDescriptor(u"GetAllDigitalInputChannels",
                                [],
                                 u"Gets the logical value 0 or 1 of all the signals applied to all channels as a tuple e.G. (1,1,1,1)",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful). In this case the returnvalue is also a tuple. e.G. (0,(1,1,1,1)) ",
                                     type=PropertyTypeId.object )
                              ),
                              JobDescriptor(u"SetDACChannelVoltage",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the DAC channel, "
                                        u"according to connector panel labelling (0-13)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"voltage",
                                        displayName=u"voltage",
                                        description=u"The voltage which should be applied"
                                        u"Voltage: 0.0V - 10.0V",
                                        type=PropertyTypeId.float,
                                        default=0
                                    )
                                 ],
                                 u"Applies the given voltage to the specified channel.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object )
                              ),
                              JobDescriptor(u"SetDACChannelValue",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the DAC channel, "
                                        u"according to connector panel labelling (0-13)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"dacValue",
                                        displayName=u"dacValue",
                                        description=u"The digital dac value which should be applied"
                                        u"Voltage: 0 - 4095",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Sets the given digital dac value to the specified channel",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                              ),
                              JobDescriptor(u"SetLockChannelDACVoltage",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"voltageChannel0",
                                        displayName=u"voltageChannel0",
                                        description=u"The voltage which should be applied to channel 0 "
                                        u"voltageChannel0: 0.0V - 10V",
                                        type=PropertyTypeId.float,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"voltageChannel1",
                                        displayName=u"voltageChannel1",
                                        description=u"The voltage which should be applied to channel 1 "
                                        u"voltageChannel1: 0.0V - 10V",
                                        type=PropertyTypeId.float,
                                        default=0
                                    ),
                                 ],
                                 u"Applies the given voltages for channel 0 and 1. Both channels are controlled simultaneously.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object )
                              ),
                              JobDescriptor(u"SetLockChannelDACValue",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"dacValueChannel0",
                                        displayName=u"dacValueChannel0",
                                        description=u"The digital dac value which for channel 0"
                                        u"dacValueChannel0: 0 - 4095",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                   PropertyDescriptor.CreateInstance(
                                        name=u"dacValueChannel1",
                                        displayName=u"dacValueChannel1",
                                        description=u"The digital dac value which for channel 1"
                                        u"dacValueChannel1: 0 - 4095",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                 ],
                                 u"Applies the given digital DAC value for channel 0 and 1. Both channels are controlled simultaneously.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object )
                              ),
                              JobDescriptor(u"GetADCChannelVoltage",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the ADC channel, "
                                        u"according to connector panel labelling (0-3)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Gets the current measured voltage at the given ADC channel.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object )
                              ),
                              JobDescriptor(u"GetADCChannelValue",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the ADC channel, "
                                        u"according to connector panel labelling (0-3)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Gets the current measured voltage as a digital ADC value.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object )
                              ),
                               JobDescriptor(u"SetRelayStatus",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the relay channel, "
                                        u"according to connector panel labelling (0-4)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"status",
                                        displayName=u"status",
                                        description=u"relay On-Off Status (0-Off, 1-On)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Sets the status of the given relay to ON or OFF ",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"SetPWMOutputChannel",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the PWM output channel, "
                                        u"according to connector panel labelling (0-3)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"frequency",
                                        displayName=u"frequency",
                                        description=u"The frequency of the PWM signal (0Hz - 10000Hz)",
                                        type=PropertyTypeId.float,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"dutyCycle",
                                        displayName=u"dutyCycle",
                                        description=u"The dutyCycle of the PWM signal (0% - 100%)",
                                        type=PropertyTypeId.float,
                                        default=0
                                    )
                                 ],
                                 u"Generates a PWM signal with the given frequency and duty cycle at the given PWM channel",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"ConfigurePWMOutputVoltage",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"referenceVoltageSelector",
                                        displayName=u"referenceVoltageSelector",
                                        description=u"The PWM output voltage selector, "
                                        u"5 - 5V, 12 - UBD",
                                        type=PropertyTypeId.int,
                                        default=5
                                    ),
                                 ],
                                 u"Configures the reference voltage of teh PWM outputs",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"ConfigurePWMInputChannel",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the PWM input channel, "
                                        u"according to connector panel labelling (0-3)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"referenceVoltageSelector",
                                        displayName=u"referenceVoltageSelector",
                                        description=u"The referenceVoltageSelector of the PWM for the given PWM input channel"
                                        u"(0 - Pull-Up, 1 - VRef, 2 - Pull-Down)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Configures the reference voltage for the given PWM input channel",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"ConfigureAllPWMInputChannels",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"referenceVoltageSelector",
                                        displayName=u"referenceVoltageSelector",
                                        description=u"The referenceVoltageSelector of the PWM for the given PWM input channel"
                                        u"(0 - Pull-Up, 1 - VRef, 2 - Pull-Down)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Configures the reference voltage for all PWM input channels",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"GetPWMInputChannel",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the PWM input channel, "
                                        u"according to connector panel labelling (0-3)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Gets the frequency and duty cycle of the signal which is applied to the given channel.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)"
                                     u"ResultValue is a tuple of frequency and duty cycle (frequency, dutyCycle)",
                                     type=PropertyTypeId.object)
                              ),
                               JobDescriptor(u"ConfigureMiscellaneousChannel",
                                [
                                     PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the miscellaneous channel, "
                                        u"according to connector panel labelling  0 - 2 (0 = Injector, 1 = Ignition, 2 = Main Relay)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"referenceVoltageSelector",
                                        displayName=u"referenceVoltageSelector",
                                        description=u"The configuration of the given miscellaneous channel"
                                        u"( 0 - Pull-Down, 1 - Pull-Up)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Configures the given miscellaneous channel.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"GetMiscellaneousChannel",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the miscellaneous channel, "
                                        u"according to connector panel labelling  0 - 2 (0 = Injector, 1 = Ignition, 2 = Main Relay)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Returns the logical value (0 or 1) of the signal applied to the given channel",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                              ),
                              JobDescriptor(u"GetAllMiscellaneousChannels",
                                [],
                                 u"Gets the logical value 0 or 1 of all the signals applied to all channels as a tuple e.G. (1,1,1)",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful). In this case the returnvalue is also a tuple. e.G. (0,(1,1,1)) ",
                                     type=PropertyTypeId.object )
                              ),
                              JobDescriptor(u"GetUBDVoltage",
                                [],
                                 u"Measures the currently applied battery voltage. Battery means in that contect the voltage of teh power supply which is sourcing CATS.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                              ),
                              JobDescriptor(u"GetUBDValue",
                                [],
                                 u"Measures the currently applied battery voltage and returns the digital value. Battery means in that contect the voltage of teh power supply which is sourcing CATS.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                              ),
                              JobDescriptor(u"SetEngineSpeed",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"engineSpeedInRPM",
                                        displayName=u"engineSpeedInRPM",
                                        description=u"The RPM of the crankshaft"
                                        u"engineSpeedInRPM :  0 RPM - 7500 RPM",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Sets the RPM of the crankshaft.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"SetCrankMode",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"crankMode",
                                        displayName=u"crankMode",
                                        description=u"The Signal mode for the crankshaft signal."
                                        u"crankMode :  0 - TTL;  1 - Differential ",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Sets the signal mode for the crankshaft signal.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"SetCrankSingleVoltage",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"voltage",
                                        displayName=u"voltage",
                                        description=u"The Signal voltage for a single ended crankshaft signal."
                                        u"voltage :  0.0V - 10.0V",
                                        type=PropertyTypeId.float,
                                        default=0
                                    )
                                 ],
                                 u"Sets the voltage for a single ended crankshaft signal.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"SetCrankDifferentialVoltage",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"voltage",
                                        displayName=u"voltage",
                                        description=u"The Signal voltage for a diferential crankshaft signal."
                                        u"voltage :  0V - 10V in 1V setps",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Sets the voltage for a differential crankshaft signal.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"SelectCrankPattern",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"patternIndex",
                                        displayName=u"patternIndex",
                                        description=u"The index of the pattern stored in CATS which should be applied as to the crankshaft signal."
                                        u"patternIndex :  1 - 6 (the slot where the pattern is available)",
                                        type=PropertyTypeId.int,
                                        default=1
                                    )
                                 ],
                                 u"Sets the crankshaft pattern.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"SetCamMode",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the camshaft channel, "
                                        u"according to connector panel labelling  1 - 4",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),

                                    PropertyDescriptor.CreateInstance(
                                        name=u"camMode",
                                        displayName=u"camMode",
                                        description=u"The Signal mode for the camshaft signal."
                                        u"crankMode :  0 - Differential;  1 - TTL ",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Sets the signal mode for the camshaft signal for the given channel.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"SelectCamPattern",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"patternIndex",
                                        displayName=u"patternIndex",
                                        description=u"The index of the pattern stored in CATS which should be applied as to the camshaft signal."
                                        u"patternIndex :  1 - 6 (the slot where the pattern is available)",
                                        type=PropertyTypeId.int,
                                        default=1
                                    )
                                 ],
                                 u"Sets the camshaftshaft pattern.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"SetCamPhase",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"Identifier of the camshaft channel, "
                                        u"according to connector panel labelling  1 - 4",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),

                                    PropertyDescriptor.CreateInstance(
                                        name=u"angle",
                                        displayName=u"angle",
                                        description=u"The phase shift angle between crankshaft and camshaft "
                                        u"crankMode :  0 - TTL;  1 - Differential ",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Sets the signal mode for the camshaft signal for teh given channel.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"SetDG23iMode",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"dg23iMode",
                                        displayName=u"dg23iMode",
                                        description=u"Turns the dgi23i mode on or off, "
                                        u" 0 - Off, 1 - On",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"direction",
                                        displayName=u"direction",
                                        description=u"The direction of the dgi23i signal. "
                                        u"crankMode :  0 - Forward, 1 - Backward",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                ],
                                u"Turn the dg23i mode on or off",
                                PropertyDescriptor.CreateInstance(
                                    name=u"result",
                                    description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                    type=PropertyTypeId.object)
                                ),
                              JobDescriptor(u"StartRPMRamp",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"startRPM",
                                        displayName=u"startRPM",
                                        description=u"start value for the ramp funktion. The ramp is starting at this RPM value. "
                                        u"(0 - 7500)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"stopRPM",
                                        displayName=u"stopRPM",
                                        description=u"stop value for the ramp funktion. The ramp is stopping at this RPM value. It has to be greater than startRPM."
                                        u"(0 - 7500)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                     PropertyDescriptor.CreateInstance(
                                        name=u"duration",
                                        displayName=u"duration",
                                        description=u"The duration for the gerneration of the RPM values in between startRPM and stopRPM. This leads to a velocity how fast the equidistant rpm steps are processed."
                                        u"It is a time in compleat seconds.",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"voltage",
                                        displayName=u"voltage",
                                        description=u"The voltage in case of an differentail signal."
                                        u"Voltage as an Integer :  0V - 10V",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Is ramping the rpm from a start value to a stop value during the given time.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object),
                              ),
                              JobDescriptor(u"StopRPMRamp",
                                [],
                                 u"Stops the current ",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                              ),
                              JobDescriptor(u"GetRPM",
                                [],
                                 u"Returns the actual configured RPM value.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                              ),
                              JobDescriptor(u"StartSENTTransimition",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"status",
                                        displayName=u"status",
                                        description=u"The status of a SENT message "
                                        u"(0 - 15)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"nibbles",
                                        displayName=u"nibbles",
                                        description=u"nibbles 1 to 6 as an array of values 0-15",
                                        type=PropertyTypeId.object,
                                        default=[0,0,0,0,0,0]
                                    ),
                                     PropertyDescriptor.CreateInstance(
                                        name=u"clockTick",
                                        displayName=u"clockTick",
                                        description=u"The clockTick parameter 3ms - 90ms",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"frameLengthType",
                                        displayName=u"frameLengthType",
                                        description=u"Selects the type of the frame length 0 - Variable Frame length, 1 - Fix Frame length ",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"framelength",
                                        displayName=u"framelength",
                                        description=u"If frameLengthType = 1 it defines the frame length from -282ms - 922ms",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"lowpulseLength",
                                        displayName=u"lowpulseLength",
                                        description=u"5 - 10",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"crcMode",
                                        displayName=u"crcMode",
                                        description=u"0 - Legacy, 1 - Recommented CRC",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"polarity",
                                        displayName=u"polarity",
                                        description=u"0 - Active-High, 1 - Active-Low",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"sensorType",
                                        displayName=u"sensorType",
                                        description=u"0 - 4 ",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Start SENT transmission",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                                 ),
                              
                              JobDescriptor(u"ResetDevice",
                                [],
                                 u"Resets the CATS device",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                              ),
                              JobDescriptor(u"GetFirmwareVersion",
                                [],
                                 u"Returns the current firmware version in hex coding.",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                              ),
                              JobDescriptor(u"MonitorPowerSupplyVoltage",
                                [],
                                 u"Returns the voltage of the actually connected power supply",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                              ),
                              JobDescriptor(u"SetHBridgeOut",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channel",
                                        displayName=u"channel of H-Bridge",
                                        description=u"Selecteds teh channel of teh H-Bridge ",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"frequency",
                                        displayName=u"frequency",
                                        description=u"Sets the frequency of the H-bridge",
                                        type=PropertyTypeId.int,
                                        default=1000
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"dutyCycle",
                                        displayName=u"dutyCycle",
                                        description=u"Sets the dutyCycle of the H-bridge",
                                        type=PropertyTypeId.int,
                                        default=50
                                    ),
                              ],
                               u"Result",
                                PropertyDescriptor.CreateInstance(
                                    name=u"result",
                                    description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                    type=PropertyTypeId.object)
                                ),
                                            
                              JobDescriptor(u"StopHBridgeOut",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channel",
                                        displayName=u"channel of H-Bridge",
                                        description=u"Selecteds teh channel of teh H-Bridge ",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                ],
                                u"Result",
                                PropertyDescriptor.CreateInstance(
                                    name=u"result",
                                    description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                    type=PropertyTypeId.object)
                                ),
                            ]
        return(jobDescriptors)
    
    def __GenerateCats20Tooljobs__(self):
        cats20Descriptors = [
                             
                            ]
        commonDescriptors = self.__GenerateCommonTooljobs__()
        jobDescriptors = commonDescriptors + cats20Descriptors
        return jobDescriptors

    def __GenerateCats22Tooljobs__(self):
         cats22Descriptors = [
                            JobDescriptor(u"SendCANmsgcyclic",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"The can channel id",
                                        type=PropertyTypeId.int,
                                        default=1
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"datarate",
                                        displayName=u"datarate",
                                        description=u"The interval in ms within the message will be send",
                                        type=PropertyTypeId.object,
                                        default=10
                                    ),
                                     PropertyDescriptor.CreateInstance(
                                        name=u"idType",
                                        displayName=u"idType",
                                        description=u"The idType wich will be used. 0-Standrad, 1-Extended",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"datalength",
                                        displayName=u"datalength",
                                        description=u"The length of the transmited data 0-8",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"msgObject",
                                        displayName=u"msgObject",
                                        description=u"The can message object 0x1 - 0xF",
                                        type=PropertyTypeId.int,
                                        default=0x1
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"msgID",
                                        displayName=u"msgID",
                                        description=u"The can message id",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"mask",
                                        displayName=u"mask",
                                        description=u"CAN masl 0x00 - 0xFF",
                                        type=PropertyTypeId.int,
                                        default=0xFF
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"data1",
                                        displayName=u"data1",
                                        description=u"Most significant Byte 0x00 - 0xFF",
                                        type=PropertyTypeId.int,
                                        default=0x00
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"data2",
                                        displayName=u"data2",
                                        description=u"Byte 0x00 - 0xFF",
                                        type=PropertyTypeId.int,
                                        default=0x00
                                    ),PropertyDescriptor.CreateInstance(
                                        name=u"data3",
                                        displayName=u"data3",
                                        description=u"Byte 0x00 - 0xFF",
                                        type=PropertyTypeId.int,
                                        default=0x00
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"data4",
                                        displayName=u"data4",
                                        description=u"Byte 0x00 - 0xFF",
                                        type=PropertyTypeId.int,
                                        default=0x00
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"data5",
                                        displayName=u"data5",
                                        description=u"Byte 0x00 - 0xFF",
                                        type=PropertyTypeId.int,
                                        default=0x00
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"data6",
                                        displayName=u"data6",
                                        description=u"Byte 0x00 - 0xFF",
                                        type=PropertyTypeId.int,
                                        default=0x00
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"data7",
                                        displayName=u"data7",
                                        description=u"Byte 0x00 - 0xFF",
                                        type=PropertyTypeId.int,
                                        default=0x00
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"data8",
                                        displayName=u"data8",
                                        description=u"Least significant Byte 0x00 - 0xFF",
                                        type=PropertyTypeId.int,
                                        default=0x00
                                    ),
                                 ],
                                 u"Result",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                                 ),
                            JobDescriptor(u"ConfigureCanModule",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"The can channel id",
                                        type=PropertyTypeId.int,
                                        default=1
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"baudrate",
                                        displayName=u"baudrate",
                                        description=u"The bauderate of the CAN bus",
                                        type=PropertyTypeId.object,
                                        default=10
                                    ),
                                 ],
                                 u"Result",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                                 ),
                            JobDescriptor(u"ConfigureCANRxFilter",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"The can channel id",
                                        type=PropertyTypeId.int,
                                        default=1
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"msgObject",
                                        displayName=u"msgObject",
                                        description=u"The can message object 0x1 - 0xF",
                                        type=PropertyTypeId.int,
                                        default=0x1
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"msgID",
                                        displayName=u"msgID",
                                        description=u"The can message id",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                     PropertyDescriptor.CreateInstance(
                                        name=u"mask",
                                        displayName=u"mask",
                                        description=u"CAN masl 0x00 - 0xFF",
                                        type=PropertyTypeId.int,
                                        default=0xFF
                                    ),
                                     PropertyDescriptor.CreateInstance(
                                        name=u"idType",
                                        displayName=u"idType",
                                        description=u"The idType wich will be used. 0-Standrad, 1-Extended",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                     PropertyDescriptor.CreateInstance(
                                        name=u"datalength",
                                        displayName=u"datalength",
                                        description=u"The length of the transmited data 0-8",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                 ],
                                 u"Result",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                                 ),
                             JobDescriptor(u"ReadCANmessagecyclic",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channelId",
                                        displayName=u"channelId",
                                        description=u"The can channel id",
                                        type=PropertyTypeId.int,
                                        default=1
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"msgObject",
                                        displayName=u"msgObject",
                                        description=u"The can message object 0x1 - 0xF",
                                        type=PropertyTypeId.int,
                                        default=0x1
                                    ),
                                 ],
                                 u"Result",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                                 ),
                             JobDescriptor(u"StartSENTTransimitionByChannel",
                                [
                                    PropertyDescriptor.CreateInstance(
                                        name=u"channel",
                                        displayName=u"The SENT channel",
                                        description=u"The status of a SENT message "
                                        u"(0 - 1)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"status",
                                        displayName=u"status",
                                        description=u"The status of a SENT message "
                                        u"(0 - 15)",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"nibbles",
                                        displayName=u"nibbles",
                                        description=u"nibbles 1 to 6 as an array of values 0-15",
                                        type=PropertyTypeId.object,
                                        default=[0,0,0,0,0,0]
                                    ),
                                     PropertyDescriptor.CreateInstance(
                                        name=u"clockTick",
                                        displayName=u"clockTick",
                                        description=u"The clockTick parameter 3ms - 90ms",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"frameLengthType",
                                        displayName=u"frameLengthType",
                                        description=u"Selects the type of the frame length 0 - Variable Frame length, 1 - Fix Frame length ",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"framelength",
                                        displayName=u"framelength",
                                        description=u"If frameLengthType = 1 it defines the frame length from -282ms - 922ms",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"lowpulseLength",
                                        displayName=u"lowpulseLength",
                                        description=u"5 - 10",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"crcMode",
                                        displayName=u"crcMode",
                                        description=u"0 - Legacy, 1 - Recommented CRC",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"polarity",
                                        displayName=u"polarity",
                                        description=u"0 - Active-High, 1 - Active-Low",
                                        type=PropertyTypeId.int,
                                        default=0
                                    ),
                                    PropertyDescriptor.CreateInstance(
                                        name=u"sensorType",
                                        displayName=u"sensorType",
                                        description=u"0 - 4 ",
                                        type=PropertyTypeId.int,
                                        default=0
                                    )
                                 ],
                                 u"Start SENT transmission",
                                 PropertyDescriptor.CreateInstance(
                                     name=u"result",
                                     description=u"Return value as tuple (JobResult,ReturnValue) (JobResult = 0 if successful)",
                                     type=PropertyTypeId.object)
                                 ),
                             ]
         commonDescriptors = self.__GenerateCommonTooljobs__()
         jobDescriptors = commonDescriptors + cats22Descriptors
         return jobDescriptors

    def __GenerateDDLPath__(self):
         dllPath = os.path.dirname(__file__)
         dllPath = os.path.join(dllPath,"CatsTooladapter")
         dllPath = os.path.join(dllPath,"CATS_API")
         dllPath = os.path.join(dllPath,"ClassLibrary_CATS_2_0_2_2")
         return(dllPath)

    def __ConnectCats__(self):
        if CatsToolAdapter.CatsdllsLoaded :
           Logger().LogInfo("Cats ddl's already loaded. Dll's can only be loaded once in a process. To force reload the dll's please restart ECU-TEST")
           return
        dllPath = self.__GenerateDDLPath__()
        Logger().LogInfo(dllPath)
        Logger().LogInfo(os.path.dirname(dllPath))
        sys.path.append(os.path.dirname(dllPath))
        Logger().LogInfo(os.path.basename(dllPath))
        clr.AddReference(os.path.basename(dllPath))
        catsVersion = ""
        try:
            from BridgeLibraryCat2_0_2_2 import BridgeDll
            bridge = BridgeDll()
            param = None
            CatsToolAdapter.CatsInterfaceTuple = bridge.LoadingDll(param)
            CatsToolAdapter.CatsdllsLoaded = True
        except Exception as e:
            Logger().LogError("Failed to connect Cats. Message "+str(e.message))

    def __GetCatsVersion__(self):
         catsVersion = CatsToolAdapter.CatsInterfaceTuple[0]
         return catsVersion

    def __init__(self, toolname = ""):
       
        """
        Constructor that defines available API methods from the CATS.dll
        """
        self.catsInterfaceTuple = None
        self.CatsAPIHandler = None
        jobDescriptors = []
        self.__ConnectCats__()
        catsVersion = self.__GetCatsVersion__()
        Logger().LogInfo("Cats-Version detected: "+catsVersion)
        dllPath = self.__GenerateDDLPath__()
        if(catsVersion == "CATS_2_2"):
           jobDescriptors = self.__GenerateCats22Tooljobs__()
           self.CatsAPIHandler = CatsAPIHandler22(CatsToolAdapter.CatsInterfaceTuple[1])
        elif(catsVersion == "CATS_2_0"):
             jobDescriptors = self.__GenerateCats20Tooljobs__()
             self.CatsAPIHandler = CatsAPIHandler20(CatsToolAdapter.CatsInterfaceTuple[1])
        ToolAdapter.__init__(self)
        self._toolDesc = ToolDescriptor(
                            toolname, [], 0, [],jobDescriptors
                                   
                    )
        

    def IsBroken(self):
        returnValue = self.CatsAPIHandler == None
        return returnValue

   
    def OnConfigure(self):
        pass

   
    def OnUnconfigure(self):
        pass

    def OnShutdown(self):
        self.CatsAPIHandler = None

    def JobConnectDevice(self):
        try:
            self.CatsAPIHandler.ConnectDevice()
            return(0,None)
        except APICallException:
            return(1, None)

    def JobIsDeviceConnected(self):
        try:
            result = self.CatsAPIHandler.IsDeviceConnected()
            return(0,result)
        except APICallException:
            return(1, None)
    
    def JobDisconnectDevice(self):
        try:
            self.CatsAPIHandler.DisconnectDevice()
            return(0, None)
        except APICallException:
            return(1, None)

    def JobSetDigitalOutputStatus(self, channelId, status):
        try:
            self.CatsAPIHandler.SetDigitalOutputChannelStatus(channelId, status)
            return(0,None)
        except APICallException:
            return(1,None)

    def JobConfigureDigitalOutputVoltage(self, referenceVoltageSelector):
       try:
           self.CatsAPIHandler.ConfigureDigitalOutputVoltage(referenceVoltageSelector)
           return(0,None)
       except APICallException:
           return(1,None)  

    def JobConfigureDigitalInputChannel(self, channelId, referenceVoltageSelector):
       try:
           self.CatsAPIHandler.ConfigureDigitalInputChannel(channelId, referenceVoltageSelector)
           return(0,None)
       except APICallException:
           return(1,None) 
    
    def JobConfigureAllDigitalInputChannels(self, referenceVoltageSelector):
       try:
           self.CatsAPIHandler.ConfigureAllDigitalInputChannels(referenceVoltageSelector)
           return(0,None)
       except APICallException:
           return(1,None) 

    def JobGetDigitalInputChannel(self, channelId):
       try:
           result = self.CatsAPIHandler.GetDigitalInputChannel(channelId)
           return(0,result)
       except APICallException:
           return(1,None)

    def JobGetAllDigitalInputChannels(self):
       try:
           result = self.CatsAPIHandler.GetAllDigitalInputChannels()
           return(0,result)
       except APICallException:
           return(1,None)

    def JobSetDACChannelVoltage(self, channelId, voltage):
       try:
           self.CatsAPIHandler.SetDACChannelVoltage(channelId,voltage)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobSetDACChannelValue(self, channelId, dacValue):
       try:
           self.CatsAPIHandler.SetDACChannelValue(channelId, dacValue)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobSetLockChannelDACVoltage(self, voltageChannel0, voltageChannel1):
       try:
           self.CatsAPIHandler.SetLockChannelDACVoltage(voltageChannel0, voltageChannel1)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobSetLockChannelDACValue(self, dacValueChannel0, dacValueChannel1):
       try:
           self.CatsAPIHandler.SetLockChannelDACValue(dacValueChannel0, dacValueChannel1)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobGetADCChannelVoltage(self, channelId):
       try:
           result = self.CatsAPIHandler.GetADCChannelVoltage(channelId)
           return(0,result)
       except APICallException:
           return(1,None)

    def JobGetADCChannelValue(self, channelId):
       try:
           result = self.CatsAPIHandler.GetADCChannelValue(channelId)
           return(0,result)
       except APICallException:
           return(1,None)

    def JobSetRelayStatus(self, channelId, status):
       try:
           self.CatsAPIHandler.SetRelayStatus(channelId, status)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobSetPWMOutputChannel(self, channelId, frequency, dutyCycle):
       try:
           self.CatsAPIHandler.SetPWMOutputChannel(channelId,frequency, dutyCycle)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobConfigurePWMOutputVoltage(self, referenceVoltageSelector):
       try:
           self.CatsAPIHandler.ConfigurePWMOutputVoltage(referenceVoltageSelector)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobConfigurePWMInputChannel(self, channelId, referenceVoltageSelector):
       try:
           self.CatsAPIHandler.ConfigurePWMInputChannel(channelId, referenceVoltageSelector)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobConfigureAllPWMInputChannels(self,  referenceVoltageSelector):
       try:
           self.CatsAPIHandler.ConfigureAllPWMInputChannels(referenceVoltageSelector)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobGetPWMInputChannel(self,  channelId):
       try:
           result = self.CatsAPIHandler.GetPWMInputChannel(channelId)
           return(0,result)
       except APICallException:
           return(1,None)

    def JobConfigureMiscellaneousChannel(self,  channelId, referenceVoltageSelector):
       try:
           self.CatsAPIHandler.ConfigureMiscellaneousChannel(channelId, referenceVoltageSelector)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobGetMiscellaneousChannel(self,  channelId):
       try:
           result = self.CatsAPIHandler.GetMiscellaneousChannel(channelId)
           return(0,result)
       except APICallException:
           return(1,None)

    def JobGetAllMiscellaneousChannels(self):
       try:
           result = self.CatsAPIHandler.GetAllMiscellaneousChannels()
           return(0,result)
       except APICallException:
           return(1,None)

    def JobGetUBDVoltage(self):
       try:
           result = self.CatsAPIHandler.GetUBDVoltage()
           return(0,result)
       except APICallException:
           return(1,None)

    def JobGetUBDValue(self):
       try:
           result = self.CatsAPIHandler.GetUBDValue()
           return(0,result)
       except APICallException:
           return(1,None)
    
    def JobSetEngineSpeed(self, engineSpeedInRPM):
       try:
           self.CatsAPIHandler.SetEngineSpeed(engineSpeedInRPM)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobSetCrankMode(self, crankMode):
       try:
           self.CatsAPIHandler.SetCrankMode(crankMode)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobSetCrankSingleVoltage(self, voltage):
       try:
           self.CatsAPIHandler.SetCrankSingleVoltage(voltage)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobSetCrankDifferentialVoltage(self, voltage):
       try:
           self.CatsAPIHandler.SetCrankDifferentialVoltage(voltage)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobSelectCrankPattern(self, patternIndex):
       try:
           self.CatsAPIHandler.SelectCrankPattern(patternIndex)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobSetCamMode(self, channelId, camMode):
       try:
           self.CatsAPIHandler.SetCamMode(channelId, camMode)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobSelectCamPattern(self, patternIndex):
       try:
           self.CatsAPIHandler.SelectCamPattern(patternIndex)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobSetCamPhase(self, channelId, angle):
       try:
           self.CatsAPIHandler.SetCamPhase(channelId, angle)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobSetDG23iMode(self, dg23iMode, direction):
       try:
           self.CatsAPIHandler.SetDG23iMode(dg23iMode, direction)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobStartRPMRamp(self, startRPM, stopRPM, duration, voltage):
       try:
           self.CatsAPIHandler.StartRPMRamp(startRPM, stopRPM, duration, voltage)
           return(0,None)
       except APICallException:
           return(1,None)

    def JobStopRPMRamp(self):
       try:
           result = self.CatsAPIHandler.StopRPMRamp()
           return(0,result)
       except APICallException:
           return(1,None)

    def JobGetRPM(self):
       try:
           result = self.CatsAPIHandler.GetRPM()
           return(0,result)
       except APICallException:
           return(1,None)

    def JobStartSENTTransimitionByChannel(self, channel, status,nibbles,clockTick,frameLengthType,framelength,lowpulseLength,crcMode,polarity,sensorType):
       try:
           result = self.CatsAPIHandler.StartSENTTransimition(channel, status, nibbles, clockTick, frameLengthType,framelength,lowpulseLength,crcMode,polarity,sensorType)
           return(0,result)
       except APICallException:
           return(1,None)

    def JobStartSENTTransimition(self, status, nibbles, clockTick, frameLengthType, framelength, lowpulseLength, crcMode, polarity, sensorType):
       try:
           result = self.CatsAPIHandler.StartSENTTransimition(0, status, nibbles, clockTick, frameLengthType,framelength,lowpulseLength,crcMode,polarity,sensorType)
           return(0,result)
       except APICallException:
           return(1,None)

    def JobResetDevice(self):
       try:
           self.CatsAPIHandler.ResetDevice()
           return(0,None)
       except APICallException:
           return(1,None)
    
    def JobGetFirmwareVersion(self):
       try:
           result = self.CatsAPIHandler.GetFirmwareVersion()
           return(0,result)
       except APICallException:
           return(1,None)

    def JobMonitorPowerSupplyVoltage(self):
       try:
           result = self.CatsAPIHandler.MonitorPowerSupplyVoltage()
           return(0,result)
       except APICallException:
           return(1,None)

    def JobSetHBridgeOut(self,channel, frequency, dutyCycle):
       try:
           result = self.CatsAPIHandler.SetHBridgeOut(channel, frequency, dutyCycle)
           return(0,result)
       except APICallException:
           return(1,None)

    def JobStopHBridgeOut(self,channel):
       try:
           result = self.CatsAPIHandler.StopHBridgeOut(channel)
           return(0,result)
       except APICallException:
           return(1,None)

    def JobSendCANmsgcyclic(self, channelId, datarate, idType, datalength, msgObject, msgID, mask, data1, data2, data3, data4, data5, data6, data7, data8):
       try:
           result = self.CatsAPIHandler.SendCANmsgcyclic(channelId, datarate, idType, datalength, msgObject, msgID, mask, data1, data2, data3, data4, data5, data6, data7, data8)
           return(0,result)
       except APICallException:
           return(1,None)

    def JobConfigureCanModule(self, channelId, baudrate):
       try:
           result = self.CatsAPIHandler.ConfigureCanModule(channelId, baudrate)
           return(0,result)
       except APICallException:
           return(1,None)

    def JobConfigureCANRxFilter(self, channelId, msgObject, msgID, mask, idType, datalength):
       try:
           result = self.CatsAPIHandler.ConfigureCANRxFilter(channelId, msgObject, msgID, mask, idType, datalength)
           return(0,result)
       except APICallException:
           return(1,None)
    
    def JobReadCANmessagecyclic(self, channelId, msgObject):
       try:
           result = self.CatsAPIHandler.ReadCANmessagecyclic(channelId, msgObject)
           return(0,result)
       except APICallException:
           return(1,None)