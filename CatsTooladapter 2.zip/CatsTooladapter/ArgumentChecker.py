﻿
import os
import sys
import types
import numbers
from abc import ABCMeta


IsECUTestContext = False
if (str(sys.argv[0])[str(sys.argv[0]).rfind("."):] == ".exe"):
   IsECUTestContext = True

if (IsECUTestContext):
    from user.PLib.System.Logger import Logger, LogLevel
    from user.PLib.System.Singleton import Singleton
    from .Exceptions.APICallException  import APICallException
else:
    from PLib.System.Logger import Logger, LogLevel
    from PLib.System.Singleton import Singleton
    from CatsTooladapter.Exceptions.APICallException  import APICallException
    

class ArgumentChecker(object, metaclass=Singleton):
    __className__ = "ArgumentChecker"
    
    def __init__(self):
       self.MAXCHANNELCOUNT = None
       self.DIGITALOUTPUTVOLTAGESELECTOR = None
       self.ONOFFSTATUS = None
       self.MAXIMUMDACVOLTAGE = None
       self.MAXIMUMDACVALUE = None
       self.REFERENCEVOLTAGESELECTOR = None
       self.MAXIMUMPWMFREQUENCY = None
       self.MINIMUMPWMFREQUENCY = None
       self.MAXIMUMDUTYCYCLEPERCENT = None
       self.PWMOUTPUTVOLTAGESELECTOR = None
       self.MISCELLANEOUSCONFIGURATION = None
       self.MAXENGINESPEED = None
       self.MINENGINESPEEDCAMANGLE = None
       self.MAXENGINESPEEDCAMANGLE = None
       self.PATTERNSELECTION = None
       self.CRANKCAMMODE = None
       self.MAXIMUMCRANKVOLTAGE = None
       self.DG23IMODEDIRECTION = None
       self.CANBAUDRATES = None
       self.SENTSTATUS = None
       self.SENTNIBBLERANGE = None
       self.SENTMINCLOCKTICKS = None
       self.SENTMAXCLOCKTICKS = None
       self.SENTFRAMELENGTHTYPE = None
       self.SENTMINFRAMELENGTH = None
       self.SENTMAXFRAMELENGTH = None
       self.SENTLOWPULSELEGNTH = None
       self.SENTCRCMODE = None
       self.SENTSIGNALPOLARITY = None
       self.SENTSENSORTYPE = None
       self.SENTNIBBLESCOUNT = None
       self.HBRIDGECHANNELS = None
       self.HBRIDGEFREQUENCYRANGE = None
       self.HBRIDGEDUTYCYCLE = None
      
    def CheckType(self, value, valueType, callingMethodName):
        methodName = ArgumentChecker.__className__ + "."+callingMethodName+"."+"CheckType"
        if (valueType == float):
           result = isinstance(value, numbers.Real)
        else: 
           result = type(value) == valueType

        if (result):
            Logger().LogDebug(methodName+"type of value: "+str(value)+" is of type "+str(valueType))
            return(True)
        else:
            Logger().LogError(methodName+"type of value: "+str(value)+" is not of type "+str(valueType))
            return(False)
    
   
    def CheckAPICallStatus(self, value, callingMethodName):
        pass

    def CheckChannelID(self, channelID, channelType, callingMethodName):
        methodName = callingMethodName +": "+ArgumentChecker.__className__ + "."+"CheckChannelID"
        errorMessage = methodName
        if (not (self.CheckType(channelID,int,methodName))):
            errorMessage += ": ChannelId is not of type integer"
            raise TypeError(errorMessage)
        if (not (channelID in range(0,self.MAXCHANNELCOUNT.value[channelType]))):
            errorMessage += ": ChannelId is not in range 0 to "+str(list(range(0,self.MAXCHANNELCOUNT.value[channelType]))[-1])
            raise TypeError(errorMessage)
    
    def CheckContinuesRange(self, value, minValue, maxValue, valueType, callingMethodName):
        methodName = callingMethodName +": "+ArgumentChecker.__className__ + ".CheckContinuesRange"
        errorMessage = methodName
        if (not (self.CheckType(value,valueType,methodName))):
           errorMessage += ":"+str(value)+" is not of type "+str(valueType)
           raise TypeError(errorMessage)
        if (not (minValue <= value <= maxValue)):
            errorMessage += ": "+str(value)+" is not in range: "+str(minValue)+" < value < "+ str(maxValue)
            raise TypeError(errorMessage)

    def CheckDedicatedRange(self, value, dedicatedRange, valueType, callingMethodName):
        methodName = callingMethodName +": "+ArgumentChecker.__className__ + ".CheckExactDedicatedRange"
        errorMessage = methodName
        if (not (self.CheckType(dedicatedRange,list,methodName))):
            errorMessage += ": dedicatedRange is not of type list"
            raise TypeError(errorMessage)
        if (not (self.CheckType(value,valueType,methodName))):
            errorMessage += ": "+str(value)+" is not of type "+str(valueType)
            raise TypeError(errorMessage)
        if (not (value in dedicatedRange)):
            errorMessage += ": "+str(value)+" is not in range: "+str(dedicatedRange)
            raise TypeError(errorMessage)
