﻿import sys
import clr
import os
import sys
import types
import numbers
import time
from System import Double, Decimal, SByte, UInt16, Byte, Single


IsECUTestContext = False
if (str(sys.argv[0])[str(sys.argv[0]).rfind("."):] == ".exe"):
   IsECUTestContext = True

if (IsECUTestContext):
    from user.PLib.System.Logger import Logger, LogLevel
    from user.PLib.System.Constant import Const
    from user.PLib.System.Singleton import Singleton
    import user.PLib.System.Enum as Enum
    from ..CatsAPIHandler import CatsAPIHandler
    from ..Exceptions.APICallException  import APICallException
    from ..Exceptions.CatsInitializationException  import CatsInitializationException
    from .ArgumentCheckerCats20 import ArgumentCheckerCats20
else:
    from PLib.System.Logger import Logger, LogLevel
    from PLib.System.Constant import Const
    from PLib.System.Singleton import Singleton
    import PLib.System.Enum as Enum
    from CatsTooladapter.CatsAPIHandler import CatsAPIHandler
    from CatsTooladapter.Exceptions.APICallException  import APICallException
    from CatsTooladapter.Exceptions.CatsInitializationException  import CatsInitializationException
    from CatsTooladapter.CATS20.ArgumentCheckerCats20 import ArgumentCheckerCats20


class CatsAPIHandler20(CatsAPIHandler):
    __className__ = "CatsAPIHandler20"

    def __init__(self, catsInterface, outputWaitTime=0):   
        super(self.__class__,self).__init__(catsInterface, ArgumentCheckerCats20(), outputWaitTime)
        
    def _SetCatsAPI_(self, catsAPI):
        self.cats = catsAPI

    def ConnectDevice(self):
       """
            Connect to CATS device
       """
       methodName = CatsAPIHandler20.__className__ + ".ConnectDevice"
       self.__IsConnected__ = False
       try:
          if self.cats.DeviceConnect() == 0:
             time.sleep(self.OutputWaitTime)
             self.__IsConnected__ = True
          else:
            raise APICallException(methodName + ": Failed to connect CATS. API-Call DeviceConnect returned: 0")
       except Exception as e:
          errorMessage = methodName + ": Failed to connect CATS. Exception: " + str(e)
          Logger().LogError(errorMessage)
          raise APICallException(errorMessage)  

    def DisconnectDevice(self):
        methodName = CatsAPIHandler20.__className__ + ".DisconnectDevice"
        try:
           if self.cats.DeviceDisconnect() == 0:
              self.__IsConnected__ = False
           else:
            raise APICallException(methodName + ": Failed to connect CATS. API-Call DeviceDisconnect returned: 0")           
        except Exception as e:
           errorMessage = methodName + ": Failed to disconnect CATS. Exception: " + str(e)
           Logger().LogError(errorMessage)
           raise APICallException(errorMessage)

    def GetPWMInputChannel(self, channelId):
        super(self.__class__,self).GetPWMInputChannel(channelId)
        methodName = CatsAPIHandler20.__className__+".GetPWMInputChannel"
        errorMessage = methodName+": API-Call ReadPWMIn with channelId: "+str(channelId)+" failed."
        try:
            result = self.cats.ReadPWMinput(Byte(channelId),UInt16(0), Single(0))
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to GetPWMInputChannel with channelId: "+str(channelId)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ReadPWMIn: Status API-Call: "+str(result[0]))
        Logger().LogDebug(methodName+": ReadPWMIn: Frequency: "+str(result[1])+" DutyCycle: "+str(result[2]))
        return(result[1:])

    def SetPWMOutputChannel(self, channelId, frequency, dutyCycle):
        """
            Sets the given frequency and dutycycle to the given channel
            
            Args:
                channelId : 0-3
                frequency : 6Hz - 10000Hz
                dutyCycle : 0% - 100%
        """
        super(self.__class__,self).SetPWMOutputChannel(channelId, frequency, dutyCycle)
        methodName = CatsAPIHandler20.__className__+".SetPWMOutputChannel"
        try:
           
            decimalDutyCycle = Decimal.__overloads__[Double](dutyCycle)
            result = self.cats.WritePWMoutput(Byte(channelId), UInt16(frequency), decimalDutyCycle)
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
            time.sleep(self.OutputWaitTime)
        except Exception as e:
            errorMessage =": Failed to SetPWMOutputChannel with channelId: "+str(channelId)+" statusfrequency: "+str(frequency)+" dutyCycle: "+str(dutyCycle)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": SetPWMOut: Status API-Call: "+str(result))

    def GetDigitalInputAll(self):
        return (self.cats.ReadDigitalInputAll(Byte(0),Byte(0),Byte(0),Byte(0)))

    #def StartSENTTransimition(self, status, nibbles, clockTick, frameLengthType, framelength, lowpulseLength, crcMode, polarity, sensorType):
    #     super(self.__class__,self).StartSENTTransimition(self, 0, status, nibbles, clockTick, frameLengthType, framelength, lowpulseLength, crcMode, polarity, sensorType)
 
 

  



