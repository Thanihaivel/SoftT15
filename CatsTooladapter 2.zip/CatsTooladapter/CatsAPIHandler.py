﻿import sys
import clr
import os
import sys
import types
import numbers
import time

from System import Double, Decimal, SByte, Byte, Int32, UInt16
from abc import ABCMeta, abstractmethod

IsECUTestContext = False
if (str(sys.argv[0])[str(sys.argv[0]).rfind("."):] == ".exe"):
   IsECUTestContext = True

if (IsECUTestContext):
    from user.PLib.System.Logger import Logger, LogLevel
    from user.PLib.System.Constant import Const
    from user.PLib.System.Singleton import Singleton
    import user.PLib.System.Enum as Enum
    from .ArgumentChecker import ArgumentChecker
    from .Exceptions.APICallException  import APICallException
else:
    from PLib.System.Logger import Logger, LogLevel
    from PLib.System.Constant import Const
    from PLib.System.Singleton import Singleton
    import PLib.System.Enum as Enum
    from CatsTooladapter.ArgumentChecker import ArgumentChecker
    from CatsTooladapter.Exceptions.APICallException  import APICallException
    
class CatsAPIHandler(object, metaclass=ABCMeta):
    __className__ = "CatsAPIHandler"

    def __init__(self, catsInterface, argumentChecker=ArgumentChecker(), outputWaitTime=0):    
        self.ArgumentChecker = argumentChecker
        self.__IsConnected__ = False
        self.OutputWaitTime = outputWaitTime
        self.cats = catsInterface # Python unittest bug __InitializeCatsAPI__ cannot be called from __init__ *damn python
        self.__InitializeCatsAPI__(catsInterface, outputWaitTime)

    def __InitializeCatsAPI__(self, catsInterface, outputWaitTime):
       methodName = CatsAPIHandler.__className__+".__InitializeCatsAPI__"
       self.cats = catsInterface
    
    def __CheckAPIIsReady__(self, callingMethodName):
        methodName = callingMethodName +": "+CatsAPIHandler.__className__ + ".__CheckAPIIsReady__"
        if (self.IsDeviceConnected()):
            Logger().LogDebug(methodName+": Cats-API ready.")
        else:
            Logger().LogError(methodName+": Cats-API not ready. Please connect device first.")
            raise APICallException(methodName+": Cats-API not ready!")
    
    def IsDeviceConnected(self):
        """
            Disconnect from CATS device
        """
        return(self.__IsConnected__)
    
    @abstractmethod
    def ConnectDevice(self):
        pass

    @abstractmethod
    def DisconnectDevice(self):
        pass
    
    def SetDigitalOutputChannelStatus(self, channelId, onOffStatus):
        """
            Turn the digtal output on or off
            
            Args:
                channelId : the channel 0-3
                onOffStatus : 0 = off, 1 = on
        """
        methodName = CatsAPIHandler.__className__ + ".SetDigitalOutputChannelStatus"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        Logger().LogDebug(methodName+": onOffStatus: "+str(onOffStatus))
        errorMessage = methodName+": API-Call WriteDigitalOutput with channelId: "+str(channelId)+" onOffStatus: "+str(onOffStatus)
        errorOccured = False
        self.ArgumentChecker.CheckChannelID(channelId,self.ArgumentChecker.ChannelType.DigitalChannel,methodName)
        self.ArgumentChecker.CheckDedicatedRange(onOffStatus,self.ArgumentChecker.ONOFFSTATUS.value,int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteDigitalOutput(Byte(channelId), Byte(onOffStatus))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
            time.sleep(self.OutputWaitTime)
            Logger().LogDebug(methodName+": WriteDigitalOutput with channelId: "+str(channelId)+" onOffStatus: "+str(onOffStatus))
        except Exception as e:
            errorMessage = methodName+": Failed to WriteDigitalOutput with channelId: "+str(channelId)+" onOffStatus: "+str(onOffStatus)+ " Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteDigitalOutput: Status API-Call: "+str(result))
    
    def ConfigureDigitalOutputVoltage(self, voltageSelector):
        """
            Configures the digital output voltage 5V or 12V
            
            Args:
                voltageSelector : 0 = 5V 1 = 12V
        """
        methodName = CatsAPIHandler.__className__ + ".ConfigureDigitalOutputVoltage"
        Logger().LogDebug(methodName+": voltageSelector: "+str(voltageSelector))
        errorMessage = methodName+": API-Call WriteDigitalOutput with voltageSelector: "+str(voltageSelector)
        errorOccured = False
        self.ArgumentChecker.CheckDedicatedRange(voltageSelector,self.ArgumentChecker.DIGITALOUTPUTVOLTAGESELECTOR.value,int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteDigitalOutput(Byte(voltageSelector))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
            Logger().LogDebug(methodName+": WriteDigitalOutput with voltageSelector: "+str(voltageSelector))
        except Exception as e:
            errorMessage = methodName+": Failed to WriteDigitalOutput with voltageSelector: "+str(voltageSelector)+ " Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteDigitalOutput: Status API-Call: "+str(result))
    

    def ConfigureDigitalInputChannel(self, channelId, referenceVoltageSelector):
        """
            Configures the digital input reference voltage
            
            Args:
                channelId : 0-3
                referenceVoltageSelector : 0 = 12V, 1 = VRef, 2 = Pull-Down
        """
        methodName = CatsAPIHandler.__className__+".ConfigureDigitalInputChannel"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        Logger().LogDebug(methodName+": referenceVoltageSelector: "+str(referenceVoltageSelector))
        errorMessage = methodName+": API-Call ReadDigitalInput with channelId: "+str(channelId)+" referenceVoltageSelector: "+str(referenceVoltageSelector)+" failed."
        self.ArgumentChecker.CheckChannelID(channelId,self.ArgumentChecker.ChannelType.DigitalChannel, methodName)
        self.ArgumentChecker.CheckDedicatedRange(referenceVoltageSelector,self.ArgumentChecker.REFERENCEVOLTAGESELECTOR.value,int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.ReadDigitalInput (Byte(channelId), Byte(referenceVoltageSelector), Byte(0))
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to ReadDigitalInput with channelId: "+str(channelId)+" referenceVoltageSelector: "+str(referenceVoltageSelector)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ReadDigitalInput: Status API-Call: "+str(result))
             
    def ConfigureAllDigitalInputChannels(self, referenceVoltageSelector):
        """
            Configures the digital input reference voltage for all channels
            
            Args:
                referenceVoltageSelector : 0 = 12V, 1 = VRef, 2 = Pull-Down
        """
        for channel in range(0,self.ArgumentChecker.MAXCHANNELCOUNT.value[self.ArgumentChecker.ChannelType.DigitalChannel]):
            self.ConfigureDigitalInputChannel(channel,referenceVoltageSelector)
       

    def GetDigitalInputChannel(self, channelId):
        """
            Reads a digital input
            
            Args:
                channelId : 0-3
            
            Returns:
                Logical 0 or 1 
        """                
        methodName = CatsAPIHandler.__className__+".GetDigitalInputChannel"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        self.ArgumentChecker.CheckChannelID(channelId,self.ArgumentChecker.ChannelType.DigitalChannel, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.GetAllDigitalInputChannels()
        except Exception as e:
            errorMessage =": Failed to GetDigitalInputChannel with channelId: "+str(channelId)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage,e)
        Logger().LogDebug(methodName+": GetAllDigitalInputChannels: Result-Value: "+str(result[channelId]))
        return(result[channelId])

    def GetAllDigitalInputChannels(self):
        """
            Reads all digital inputs
            
            Returns:
                Logical 0 or 1 for all channels as a tuble e.G. (1,1,1,1)
        """       
        methodName = CatsAPIHandler.__className__+".GetAllDigitalInputChannels"
        errorMessage = methodName+": API-Call GetDigitalInputAll failed."
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.GetDigitalInputAll()
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to GetAllDigitalInputChannels Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": GetDigitalInputAll: Status API-Call: "+str(result[0]))
        Logger().LogDebug(methodName+": GetDigitalInputAll: Result-Value: "+','.join(str(result[1:])))
        return(result[1:])

    def GetDigitalInputAll(self):
        pass

    def SetDACChannelVoltage(self, channelId, voltage):
        """
            Sets a DAC channel to a specific voltage
            
            Args:
                channelId : 0-13
                voltage : 0.0V - 10.0V
        """ 
        methodName = CatsAPIHandler.__className__ + ".SetDACChannelVoltage"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        Logger().LogDebug(methodName+": voltage: "+str(voltage))
        errorMessage = methodName+": API-Call WriteDACoutput with channelId: "+str(channelId)+" voltage: "+str(voltage)
        errorOccured = False
        self.ArgumentChecker.CheckChannelID(channelId,self.ArgumentChecker.ChannelType.DACChannel, methodName)
        self.ArgumentChecker.CheckContinuesRange(voltage,0,self.ArgumentChecker.MAXIMUMDACVOLTAGE.value, float, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteDACoutput(Byte(channelId), Double(voltage))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
            time.sleep(self.OutputWaitTime)
            Logger().LogDebug(methodName+": WriteDACoutput with channelId: "+str(channelId)+" voltage: "+str(voltage))
        except Exception as e:
            errorMessage +=": Failed to WriteDACoutput with channelId: "+str(channelId)+" voltage: "+str(voltage)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteDACoutput: Status API-Call: "+str(result))

    def SetDACChannelValue(self, channelId, value):
        """
            Sets a DAC value to a specific digital value
            
            Args:
                channelId : 0-13
                value : 0 - 4095
        """ 
        methodName = CatsAPIHandler.__className__ + ".SetDACChannelValue"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        Logger().LogDebug(methodName+": value: "+str(value))
        errorMessage = methodName+": API-Call writeDACoutput with channelId: "+str(channelId)+" value: "+str(value)
        errorOccured = False
        self.ArgumentChecker.CheckChannelID(channelId, self.ArgumentChecker.ChannelType.DACChannel, methodName)
        self.ArgumentChecker.CheckContinuesRange(value, 0, self.ArgumentChecker.MAXIMUMDACVALUE.value, int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteDACoutput(Byte(channelId), UInt16(value))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
            time.sleep(self.OutputWaitTime)
            Logger().LogDebug(methodName+": writeDACoutput with channelId: "+str(channelId)+" value: "+str(value))
        except Exception as e:
            errorMessage +=": Failed to writeDACoutput with channelId: "+str(channelId)+" value: "+str(value)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": writeDACoutput: Status API-Call: "+str(result))

    def SetLockChannelDACVoltage(self, voltageChannel0, voltageChannel1):
        """
            Sets the DAC for channel 0 and 1 to the given voltages at the same time
            
            Args:
                voltageChannel0 : 0.0V - 10.0V
                voltageChannel1 : 0.0V - 10.0V
        """ 
        methodName = CatsAPIHandler.__className__ + ".SetLockChannelDACVoltage"
        Logger().LogDebug(methodName+": voltageChannel0: "+str(voltageChannel0))
        Logger().LogDebug(methodName+": voltageChannel1: "+str(voltageChannel1))
        errorMessage = methodName+": API-Call WriteLockDACoutput with voltageChannel0: "+str(voltageChannel0)+" voltageChannel1: "+str(voltageChannel1)
        errorOccured = False
        self.ArgumentChecker.CheckContinuesRange(voltageChannel0,0,self.ArgumentChecker.MAXIMUMDACVOLTAGE.value, float, methodName)
        self.ArgumentChecker.CheckContinuesRange(voltageChannel1,0,self.ArgumentChecker.MAXIMUMDACVOLTAGE.value, float, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteLockDACoutput(Double(voltageChannel0), Double(voltageChannel1))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
            time.sleep(self.OutputWaitTime)
            Logger().LogDebug(methodName+": WriteLockDACoutput with voltageChannel0: "+str(voltageChannel0)+" voltageChannel1: "+str(voltageChannel1))
        except Exception as e:
            errorMessage +=": Failed to WriteLockDACoutput with voltageChannel0: "+str(voltageChannel0)+" voltageChannel1: "+str(voltageChannel1)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteLockDACoutput: Status API-Call: "+str(result))

    def SetLockChannelDACValue(self, valueChannel0, valueChannel1):
        """
            Sets the DAC for channel 0 and 1 to the given digital values at the same time
            
            Args:
                voltageChannel0 : 0 - 4095
                voltageChannel1 : 0 - 4095
        """
        methodName = CatsAPIHandler.__className__ + ".SetLockChannelDACValue"
        Logger().LogDebug(methodName+": valueChannel0: "+str(valueChannel0))
        Logger().LogDebug(methodName+": valueChannel1: "+str(valueChannel1))
        errorMessage = methodName+": API-Call setDACVoltage with valueChannel0: "+str(valueChannel0)+" valueChannel1: "+str(valueChannel1)
        errorOccured = False
        self.ArgumentChecker.CheckContinuesRange(valueChannel0, 0, self.ArgumentChecker.MAXIMUMDACVALUE.value, int, methodName)
        self.ArgumentChecker.CheckContinuesRange(valueChannel1, 0, self.ArgumentChecker.MAXIMUMDACVALUE.value, int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteLockDACoutput(UInt16(valueChannel0), UInt16(valueChannel1))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
            time.sleep(self.OutputWaitTime)
            Logger().LogDebug(methodName+": WriteLockDACoutput with valueChannel0: "+str(valueChannel0)+" valueChannel1: "+str(valueChannel1))
        except Exception as e:
            errorMessage +=": Failed to WriteLockDACoutput with valueChannel0: "+str(valueChannel0)+" valueChannel1: "+str(valueChannel1)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteLockDACoutput: Status API-Call: "+str(result))

    def GetADCChannelVoltage(self, channelId):
        """
            Measures the voltage at the given channel.
            
            Args:
                channelId : 0-3
            Returns:
                the voltage measured at the given channel
        """
        methodName = CatsAPIHandler.__className__+".GetADCChannelVoltage"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        errorMessage = methodName+": API-Call ReadADCVoltage with channelId: "+str(channelId)+" failed."
        self.ArgumentChecker.CheckChannelID(channelId, self.ArgumentChecker.ChannelType.ADCChannel, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.ReadADCVoltage(Byte(channelId), Double(0))
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to ReadADCVoltage with channelId: "+str(channelId)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ReadADCVoltage: Status API-Call: "+str(result[0]))
        Logger().LogDebug(methodName+": ReadADCVoltage: ADC-Voltage: "+str(result[1]))
        return(result[1])

    def GetADCChannelValue(self, channelId):
        """
            Measures the voltage at the given channel and returns the related digital value.
            
            Args:
                channelId : 0-2
            Returns:
                the value in respect to the voltage measured at the given channel
        """
        methodName = CatsAPIHandler.__className__+".GetADCChannelValue"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        errorMessage = methodName+": API-Call ReadADCVoltageValue with channelId: "+str(channelId)+" failed."
        self.ArgumentChecker.CheckChannelID(channelId,self.ArgumentChecker.ChannelType.ADCChannel, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.ReadADCVoltageValue (Byte(channelId), UInt16(0))
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to ReadADCVoltageValue with channelId: "+str(channelId)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ReadADCVoltageValue: Status API-Call: "+str(result[0]))
        Logger().LogDebug(methodName+": ReadADCVoltageValue: ADC-Value: "+str(result[1]))
        return(result[1])

    def SetRelayStatus(self, channelId, status):
        """
            Turns the relay for the given channel on or off
            
            Args:
                channelId : 0-4
                status : 0 - off, 1 - on
        """
        methodName = CatsAPIHandler.__className__+".SetRelayStatus"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        Logger().LogDebug(methodName+": status: "+str(status))
        errorMessage = methodName+": API-Call WriteRelayOutput with channelId: "+str(channelId)+" status: "+str(status)+" failed."
        self.ArgumentChecker.CheckChannelID(channelId,self.ArgumentChecker.ChannelType.RelayChannel, methodName)
        self.ArgumentChecker.CheckDedicatedRange(status,self.ArgumentChecker.ONOFFSTATUS.value,int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteRelayOutput(Byte(channelId), Byte(status))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
            time.sleep(self.OutputWaitTime)
        except Exception as e:
            errorMessage +=": Failed to WriteRelayOutput with channelId: "+str(channelId)+" status: "+str(status)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteRelayOutput: Status API-Call: "+str(result))

    
    def SetPWMOutputChannel(self, channelId, frequency, dutyCycle):
        """
            Sets the given frequency and dutycycle to the given channel
            
            Args:
                channelId : 0-3
                frequency : 6Hz - 10000Hz
                dutyCycle : 0% - 100%
        """
        methodName = CatsAPIHandler.__className__+".SetPWMOutputChannel"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        Logger().LogDebug(methodName+": frequency: "+str(frequency))
        Logger().LogDebug(methodName+": dutyCycle: "+str(dutyCycle))

        self.ArgumentChecker.CheckChannelID(channelId,self.ArgumentChecker.ChannelType.DigitalChannel, methodName)
        self.ArgumentChecker.CheckContinuesRange(frequency, self.ArgumentChecker.MINIMUMPWMFREQUENCY.value,self.ArgumentChecker.MAXIMUMPWMFREQUENCY.value,float,methodName)
        self.ArgumentChecker.CheckContinuesRange(dutyCycle, 0, self.ArgumentChecker.MAXIMUMDUTYCYCLEPERCENT.value,float,methodName)
        self.__CheckAPIIsReady__(methodName)


    def ConfigurePWMOutputVoltage(self, voltageSelector):
        """
            Configures the PWM reference voltage level.
            
            Args:
                voltageSelector : 5 - 5V, 12 - UBD 
        """
        methodName = CatsAPIHandler.__className__+".ConfigurePWMOutputVoltage"
        Logger().LogDebug(methodName+": voltage: "+str(voltageSelector))

        errorMessage = methodName+": API-Call WritePWMoutput with voltageSelector: "+str(voltageSelector)+" failed."
        self.ArgumentChecker.CheckDedicatedRange(voltageSelector,self.ArgumentChecker.PWMOUTPUTVOLTAGESELECTOR.value,int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WritePWMoutput(Int32(voltageSelector))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to WritePWMoutput with voltageSelector: "+str(voltageSelector)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WritePWMoutput: Status API-Call: "+str(result))

    def ConfigurePWMInputChannel(self, channelId, referenceVoltageSelector):
        """
            Configures the PWM input reference voltage for the given channel
            
            Args:
                channelId : 0-3
                voltageSelector : 0 - Pull-Up, 1 - VRef, 2 - Pull-Down
        """
        methodName = CatsAPIHandler.__className__+".ConfigurePWMInputChannel"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        Logger().LogDebug(methodName+": referenceVoltageSelector: "+str(referenceVoltageSelector))
        errorMessage = methodName+": API-Call WritePWMinputPinConfiguration with channelId: "+str(channelId)+" referenceVoltageSelector: "+str(referenceVoltageSelector)+" failed."
        self.ArgumentChecker.CheckChannelID(channelId,self.ArgumentChecker.ChannelType.DigitalChannel, methodName)
        self.ArgumentChecker.CheckDedicatedRange(referenceVoltageSelector,self.ArgumentChecker.REFERENCEVOLTAGESELECTOR.value, int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WritePWMinputPinConfiguration(Byte(channelId), Byte(referenceVoltageSelector))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to WritePWMinputPinConfiguration with channelId: "+str(channelId)+" referenceVoltageSelector: "+str(referenceVoltageSelector)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WritePWMinputPinConfiguration: Status API-Call: "+str(result))
     
    def ConfigureAllPWMInputChannels(self, referenceVoltageSelector):
        """
            Configures the PWM input reference voltage for all channels
            
            Args:
                voltageSelector : 0 - Pull-Up, 1 - VRef, 2 - Pull-Down
        """
        for channel in range(0,self.ArgumentChecker.MAXCHANNELCOUNT.value[self.ArgumentChecker.ChannelType.DigitalChannel]):
            self.ConfigurePWMInputChannel(channel,referenceVoltageSelector)
    
    def GetPWMInputChannel(self, channelId):
        """
            measures frequency and dutyCycle at the given channel and returns the results in tuble (frequency, dutyCycle) e.G. (5000,50)
            
            Args:
                channelId : 0 - 3
        """
        methodName = CatsAPIHandler.__className__+".GetPWMInputChannel"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        self.ArgumentChecker.CheckChannelID(channelId,self.ArgumentChecker.ChannelType.DigitalChannel, methodName)
        self.__CheckAPIIsReady__(methodName)
       

    def GetUBDValue(self):
      """
            measures the voltage of the power supply and returns the voltage
            
            Returns:
                the voltage of the powersupply 0V - 36V 
      """
      methodName = CatsAPIHandler.__className__+".GetUBDVoltage"
      errorMessage = methodName+": API-Call ReadPowerSupply failed."
      self.__CheckAPIIsReady__(methodName)
      try:
         result = self.cats.ReadPowerSupply(UInt16(0))
         self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
      except Exception as e:
          errorMessage +=": Failed to measure UBD Value Exception: "+str(e)
          Logger().LogError(errorMessage)
          raise APICallException(errorMessage)
      Logger().LogDebug(methodName+": ReadPowerSupply: Status API-Call: "+str(result[0]))
      Logger().LogDebug(methodName+": ReadPowerSupply: "+str(result[1]))
      return(result[1])

    def GetUBDVoltage(self):
        """
            measures the voltage of the power supply and returns the voltage
            
            Returns:
                the voltage of the powersupply 0V - 36V 
        """
        methodName = CatsAPIHandler.__className__+".GetUBDVoltage"
        errorMessage = methodName+": API-Call ReadPowerSupply failed."
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.ReadPowerSupply(Double(0))
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to measure UBD voltage Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ReadPowerSupply: Status API-Call: "+str(result[0]))
        Logger().LogDebug(methodName+": ReadPowerSupply: "+str(result[1]))
        return(result[1])

    def ResetDevice(self):
        """
            triggers a device reset
        """
        methodName = CatsAPIHandler.__className__ + ".Reset"
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.ExecuteResetHardware()
            self.__IsConnected__ = False # workaround ToDo: Cats APi should not loose connection in case of an Reset
            Logger().LogDebug(methodName+": ResetDevice.")
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
            time.sleep(2) # workaround wait time until reconnect
            self.ConnectDevice()
        except Exception as e:
            errorMessage = methodName+": Failed to ExecuteResetHardware Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise Exception(errorMessage)

    def ConfigureMiscellaneousChannel(self, channelId, configuration):
        """
            configures the given miMiscellaneous channel
            
            Args:
                channelId : 0 - 2 (0 = Injector, 1 = Ignition, 2 = Main Relay)
                configuration : 0 - Pull-Down, 1 - Pull-Up
        """
        methodName = CatsAPIHandler.__className__+".ConfigureMiscellaneousChannel"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        Logger().LogDebug(methodName+": configuration: "+str(configuration))
        errorMessage = methodName+": API-Call WriteMiscellaneousInputPinConfiguration with channelId: "+str(channelId)+" configuration: "+str(configuration)+" failed."
        self.ArgumentChecker.CheckChannelID(channelId,self.ArgumentChecker.ChannelType.MiscChannel, methodName)
        self.ArgumentChecker.CheckDedicatedRange(configuration, self.ArgumentChecker.MISCELLANEOUSCONFIGURATION.value,int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteMiscellaneousInputPinConfiguration(Byte(channelId), Byte(configuration))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to WriteMiscellaneousInputPinConfiguration with channelId: "+str(channelId)+" configuration: "+str(configuration)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteMiscellaneousInputPinConfiguration: Status API-Call: "+str(result))

    def GetMiscellaneousChannel(self, channelId):
        """
            returns the logical value of the given miscellaneous channel
            
            Args:
                channelId : 0 - 2 (0 = Injector, 1 = Ignition, 2 = Main Relay)
            Returns:
                returns the logical value 0 or 1 of the given miscellaneous channel
        """
        methodName = CatsAPIHandler.__className__+".GetMiscellaneousChannel"
        Logger().LogDebug(methodName+": channelId: "+str(channelId))
        errorMessage = methodName+": GetAllMiscellaneousChannels failed."
        self.ArgumentChecker.CheckChannelID(channelId,self.ArgumentChecker.ChannelType.MiscChannel, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.GetAllMiscellaneousChannels()
        except Exception as e:
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage, e)
        return(result[channelId])

    def GetAllMiscellaneousChannels(self):
        """
            returns the logical value of all miscellaneous channels
               
            Returns:
                returns the logical value 0 or 1 of all channels in tuble  (Injector, Ignition, Main Relay)  e.G. (1,1,1)
        """
        methodName = CatsAPIHandler.__className__+".GetAllMiscellaneousChannels"
        errorMessage = methodName+": API-Call ReadMiscellaneousAll failed."
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.ReadMiscellaneousAll(Byte(0),Byte(0),Byte(0))
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to GetAllMiscellaneousChannels Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ReadMiscellaneousAll: Status API-Call: "+str(result[0]))
        Logger().LogDebug(methodName+": ReadMiscellaneousAll: Result-Value: "+','.join(str(result[1:])))
        return(result[1:])
    
    def SetEngineSpeed(self, engineSpeedInRPM):
        """
           sets the engine speed
            
           Args:
               engineSpeedInRPM :  0 RPM - 7500 RPM
           
        """ 
        methodName = CatsAPIHandler.__className__+".SetEngineSpeed"
        errorMessage = methodName+": API-Call WriteESMRPM failed."
        self.ArgumentChecker.CheckContinuesRange(engineSpeedInRPM,0,self.ArgumentChecker.MAXENGINESPEED.value,int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteESMRPM(UInt16(engineSpeedInRPM))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to WriteESMRPM engineSpeedInRPM: "+str(engineSpeedInRPM)+"Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteESMRPM: Status API-Call: "+str(result))

    def SetCamPhase(self, channelId, angle):
        """
           sets the cam phase for the given channel
            
           Args:
               channelId :  1 - 4
               angle: -180 - 180
           
        """
        methodName = CatsAPIHandler.__className__+".SetCamPhase"
        errorMessage = methodName+": API-Call WriteCAMPhaseShift failed."
        self.ArgumentChecker.CheckContinuesRange(channelId, 1, self.ArgumentChecker.ChannelType.EngineSpeedCamChannel, float, methodName)
        self.ArgumentChecker.CheckContinuesRange(angle,self.ArgumentChecker.MINENGINESPEEDCAMANGLE.value,self.ArgumentChecker.MAXENGINESPEEDCAMANGLE.value,float, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteCAMPhaseShift(Byte(channelId), Double(angle))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to WriteCAMPhaseShift channelId: "+str(channelId)+" angle: "+str(angle)+"Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteCAMPhaseShift: Status API-Call: "+str(result))

    def SelectCrankPattern(self, patternIndex):
        """
           selects a priviously downloaded crankshaft pattern.
            
           Args:
               patternIndex :  1 - 6 (the slot where the pattern is available)
           
        """ 
        methodName = CatsAPIHandler.__className__+".SelectCrankPattern"
        errorMessage = methodName+": API-Call ExecuteESMPattern failed."
        self.ArgumentChecker.CheckDedicatedRange(patternIndex,self.ArgumentChecker.PATTERNSELECTION.value,int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            
            result = self.cats.ExecuteESMPattern(Byte(patternIndex),"")
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to ExecuteESMPattern patternIndex: "+str(patternIndex)+"Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ExecuteESMPattern: Status API-Call: "+str(result[0])) 

    def SetCrankMode(self, mode):
        """
           selects the mode for the crankshaft signal 
            
           Args:
               mode :  0 - TTL;  1 - Differential 
           
        """ 
        methodName = CatsAPIHandler.__className__+".SetCrankMode"
        errorMessage = methodName+": API-Call WriteCrankType failed."
        self.ArgumentChecker.CheckDedicatedRange(mode,self.ArgumentChecker.CRANKCAMMODE.value,int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteCrankType(Byte(mode))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to WriteCrankType mode: "+str(mode)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteCrankType: Status API-Call: "+str(result))   

    def SetCrankSingleVoltage(self, voltage):
        """
           sets the voltage for a single ended crank signal
            
           Args:
               voltage :  0.0V - 10.0V
           
        """ 
        methodName = CatsAPIHandler.__className__+".SetCrankSingleVoltage"
        errorMessage = methodName+": API-Call WriteCrankDifferentialVoltage failed."
        self.ArgumentChecker.CheckContinuesRange(voltage,0,self.ArgumentChecker.MAXIMUMCRANKVOLTAGE.value,float, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            decimalVoltage = Decimal.__overloads__[Double](voltage)
            result = self.cats.WriteCrankDifferentialVoltage(decimalVoltage)
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to WriteCrankDifferentialVoltage voltage: "+str(voltage)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteCrankDifferentialVoltage: Status API-Call: "+str(result))

    def SetCrankDifferentialVoltage(self, voltage):
        """
           sets the voltage for a differential crank signal
            
           Args:
               voltage :  0V - 10V (only in 1V steps)
           
        """ 
        methodName = CatsAPIHandler.__className__+".SetCrankDifferentialVoltage"
        errorMessage = methodName+": API-Call WriteCrankDifferentialVoltage failed."
        self.ArgumentChecker.CheckContinuesRange(voltage,0,self.ArgumentChecker.MAXIMUMCRANKVOLTAGE.value,float, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteCrankDifferentialVoltage(Byte(voltage))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to WriteCrankDifferentialVoltage with voltage: "+str(voltage)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteCrankDifferentialVoltage: Status API-Call: "+str(result))

    def SelectCamPattern(self, patternIndex):
        """
           selects a priviously downloaded camshaft pattern.
            
           Args:
               patternIndex :  1 - 6 (the slot where the pattern is available)
           
        """ 
        methodName = CatsAPIHandler.__className__+".SelectCamPattern"
        errorMessage = methodName+": API-Call ExecuteESMPattern failed."
        self.ArgumentChecker.CheckDedicatedRange(patternIndex,self.ArgumentChecker.PATTERNSELECTION.value,int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.ExecuteESMPattern(Byte(patternIndex),"")
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to ExecuteESMPattern patternIndex: "+str(patternIndex)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ExecuteESMPattern: Status API-Call: "+str(result[0]))

    def SetCamMode(self,channelId, mode):
        """
           selects the mode for the camshaft signal 
            
           Args:
               
               channelId : 1 - 4
               mode :  0 - Differential;  1 - TTL

           
        """
        methodName = CatsAPIHandler.__className__+".SetCamMode"
        errorMessage = methodName+": API-Call WriteCAMType failed."
        self.ArgumentChecker.CheckContinuesRange(channelId, 1, self.ArgumentChecker.ChannelType.EngineSpeedCamChannel, int, methodName)
        self.ArgumentChecker.CheckDedicatedRange(mode,self.ArgumentChecker.CRANKCAMMODE.value,int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteCAMType(Byte(channelId),Byte(mode))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to WriteCAMType channelId: "+str(channelId)+" mode: "+str(mode)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteCAMType: Status API-Call: "+str(result))  

    def SetDG23iMode(self, dg23iMode, direction):
        """
          sets the crankshaft to dg23i mode 
            
           Args:
               dg23iMode :  0 - Off, 1 - On
               direction : 0 - Forward, 1 - Backward
           
        """
        methodName = CatsAPIHandler.__className__+".SetDG23iMode"
        errorMessage = methodName+": API-Call WriteCrankType failed."
        self.ArgumentChecker.CheckDedicatedRange(dg23iMode,self.ArgumentChecker.ONOFFSTATUS.value,int, methodName)
        self.ArgumentChecker.CheckDedicatedRange(direction,self.ArgumentChecker.DG23IMODEDIRECTION.value,int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteCrankType(Byte(dg23iMode), Byte(direction))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to WriteCrankType with dg23iMode: "+str(dg23iMode)+" direction: "+str(direction)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteCrankType: Status API-Call: "+str(result))

    def GetFirmwareVersion(self):
        """
           returns the firmware version of the CATS system 
            
           Returns:
               the firmware version of the CATS system
        """
        methodName = CatsAPIHandler.__className__+".GetFirmwareVersion"
        errorMessage = methodName+": API-Call ReadFirmwareversion failed."
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.ReadFirmwareversion('')
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to ReadFirmwareversion Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ReadFirmwareversion: Status API-Call: "+str(result))
        Logger().LogDebug(methodName+": ReadFirmwareversion: Result-Value: "+str(result[1]))
        return(result[1])

    def StartRPMRamp(self, startRPM, stopRPM, duration, voltage):
        """
          raming the rpm form a given start rpm to a end rpm. The ramp is compleated after the given duration. 
            
           Args:
               startRPM :  0 RPM - 7500 RPM
               stopRPM : 0 RPM - 7500 RPM
               duration : time in seconds
               voltage : 0V - 10V as integer for differential signal
           
        """
        methodName = CatsAPIHandler.__className__+".StartRPMRamp"
        errorMessage = methodName+": API-Call StartESMRamp failed. "
        self.ArgumentChecker.CheckContinuesRange(startRPM,0, self.ArgumentChecker.MAXENGINESPEED.value,int, methodName)
        self.ArgumentChecker.CheckContinuesRange(stopRPM,0, self.ArgumentChecker.MAXENGINESPEED.value,int, methodName)
        if (startRPM >=stopRPM):
            errorMessage+= " startRPM: "+str(startRPM)+" is smaller than stopRPM: "+str(stopRPM)
            Logger().LogError(errorMessage)
            raise TypeError(errorMessage)
        self.ArgumentChecker.CheckContinuesRange(duration,0, float("inf"),int, methodName)
        self.ArgumentChecker.CheckContinuesRange(voltage,0, self.ArgumentChecker.MAXIMUMCRANKVOLTAGE.value, int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.StartESMRamp(startRPM, stopRPM, voltage, duration)
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to StartESMRamp Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": StartESMRamp: Status API-Call: "+str(result))

    def GetRPM(self):
        """
          Reads the current rpm 
            
           Returns:
              the current RPM
           
        """
        methodName = CatsAPIHandler.__className__+".GetRPM"
        errorMessage = methodName+": API-Call PingRPM failed."
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.PingRPM(0)
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to PingRPM Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": PingRPM: Status API-Call: "+str(result[0]))
        Logger().LogDebug(methodName+": PingRPM: Result-Value: "+str(result[1]))
        return(result[1])

    def StopRPMRamp(self):
        """
          Stops the current RPM ramp if running
          
          Returns:
            the current RPM
        """
        methodName = CatsAPIHandler.__className__+".StopRPMRamp"
        errorMessage = methodName+": API-Call StopRPMRamp failed. "
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.StopESMRamp(UInt16(0))
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to StopRPMRamp Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": StopRPMRamp: Status API-Call: "+str(result))
        Logger().LogDebug(methodName+": StopRPMRamp: Result-Value: "+str(result[1]))
        return(result[1])

    def StartSENTTransimition(self, channel, status, nibbles, clockTick, frameLengthType, framelength, lowpulseLength, crcMode, polarity, sensorType):
        """
          starting a cycling SENT message transmittion.
           
           Args:
                status : 0 - 15
                nibbles: an array of 5 nibbles (nibble1- nibble6) with value 0 - 15 e.G. [1,2,1,3,10]
                clockTick : 3ms - 90ms
                frameLengthType : 0 - Variable frame length, 1 - Fixed frame length
                framelength : -282ms - 922ms if frameLengthType = 1
                lowpulseLength : 5 - 10
                crcMode : 0 - Legacy, 1 - Recommented CRC
                polarity : 0 - Active-High, 1 - Active-Low
                sensorType : 0 - 4 
        """
        methodName = CatsAPIHandler.__className__+".StartSENTTransimition"
        errorMessage = methodName+": API-Call writeSENTdata failed. "
        self.ArgumentChecker.CheckDedicatedRange(status, self.ArgumentChecker.SENTSTATUS.value,int, methodName)
        if (len(nibbles) != self.ArgumentChecker.SENTNIBBLESCOUNT.value):
            errorMessage += "Exactly "+str(self.ArgumentChecker.SENTNIBBLESCOUNT.value)+" nibbles are required. But "+str(len(nibbles))+" are given."
            Logger().LogError(errorMessage)
            raise TypeError(errorMessage)
        for nibble in nibbles:
            self.ArgumentChecker.CheckDedicatedRange(nibble, self.ArgumentChecker.SENTNIBBLERANGE.value,int, methodName)
        self.ArgumentChecker.CheckContinuesRange(clockTick, self.ArgumentChecker.SENTMINCLOCKTICKS.value,self.ArgumentChecker.SENTMAXCLOCKTICKS.value,int, methodName)
        self.ArgumentChecker.CheckDedicatedRange(frameLengthType, self.ArgumentChecker.SENTFRAMELENGTHTYPE.value,int, methodName)
        self.ArgumentChecker.CheckContinuesRange(framelength, self.ArgumentChecker.SENTMINFRAMELENGTH.value,self.ArgumentChecker.SENTMAXFRAMELENGTH.value, int, methodName)
        self.ArgumentChecker.CheckDedicatedRange(lowpulseLength, self.ArgumentChecker.SENTLOWPULSELEGNTH.value, int, methodName)
        self.ArgumentChecker.CheckDedicatedRange(crcMode, self.ArgumentChecker.SENTCRCMODE.value, int, methodName)
        self.ArgumentChecker.CheckDedicatedRange(polarity, self.ArgumentChecker.SENTSIGNALPOLARITY.value, int, methodName)
        self.ArgumentChecker.CheckDedicatedRange(sensorType, self.ArgumentChecker.SENTSENSORTYPE.value, int, methodName)
        
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.writeSENTdata(Byte(status), Byte(nibbles[0]), Byte(nibbles[1]),Byte(nibbles[2]),Byte(nibbles[3]),Byte(nibbles[4]),Byte(nibbles[5]), Byte(clockTick), Byte(frameLengthType), UInt16(framelength), Byte(lowpulseLength), Byte(crcMode), Byte(polarity), Byte(sensorType))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to writeSENTdata with status: "+str(status)+" nibbles: "+';'.join([str(nibble) for nibble in nibbles])+" clockTick: "+str(clockTick)+"frameLengthType: "\
                         +str(frameLengthType)+" framelength: "+str(framelength)+" lowpulseLength: "+str(lowpulseLength)+" crcMode: "+str(crcMode)+" polarity: "+str(polarity)+" sensorType: "+str(sensorType)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": writeSENTdata: Status API-Call: "+str(result))

    def StopSENTTransmission(self):
        """
          stopping the current SENT transmittion
        """
        methodName = CatsAPIHandler.__className__+".StopSENTTransmission"
        errorMessage = methodName+": API-Call StopSENTTransmission failed. "
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.StopSENTTransmission()
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to StopSENTTransmission Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": StopSENTTransmission: Status API-Call: "+str(result))

    def SetHBridgeOut(self, channel, frequency, dutyCycle):
        """
          setting frequency and dutycycle for selected H-Bridge channel
        """
        methodName = CatsAPIHandler.__className__+".SetHBridgeOut"
        errorMessage = methodName+": API-Call WriteHBridgeoutput failed. "
        self.ArgumentChecker.CheckDedicatedRange(channel, self.ArgumentChecker.HBRIDGECHANNELS.value,int, methodName)
        self.ArgumentChecker.CheckContinuesRange(frequency, self.ArgumentChecker.HBRIDGEFREQUENCYRANGE.value[0],self.ArgumentChecker.HBRIDGEFREQUENCYRANGE.value[1],int, methodName)
        self.ArgumentChecker.CheckContinuesRange(dutyCycle, self.ArgumentChecker.HBRIDGEDUTYCYCLE.value[0],self.ArgumentChecker.HBRIDGEDUTYCYCLE.value[1],int, methodName)
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.WriteHBridgeoutput(Byte(channel), UInt16(frequency), Double(dutyCycle))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to WriteHBridgeoutput Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteHBridgeoutput: Status API-Call: "+str(result))

    def StopHBridgeOut(self, channel):
        """
          stopping selected H-Bridge channel out
        """
        methodName = CatsAPIHandler.__className__+".StopHBridgeOut"
        errorMessage = methodName+": API-Call WriteHBridgeoutput failed. "
        self.__CheckAPIIsReady__(methodName)
        self.ArgumentChecker.CheckDedicatedRange(channel, self.ArgumentChecker.HBRIDGECHANNELS.value,int, methodName)
        try:
            result = self.cats.WriteHBridgeoutput(Byte(channel))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to WriteHBridgeoutput Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteHBridgeoutput: Status API-Call: "+str(result))
    
    def MonitorPowerSupplyVoltage(self):
        """
          stopping selected H-Bridge channel out
        """
        methodName = CatsAPIHandler.__className__+".MonitorPowerSupplyVoltage"
        errorMessage = methodName+": API-Call ReadPowerSupply failed. "
        self.__CheckAPIIsReady__(methodName)
        try:
            result = self.cats.ReadPowerSupply(UInt16(0))
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to ReadPowerSupply Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ReadPowerSupply: Status API-Call: "+str(result))
        return(result[1])


