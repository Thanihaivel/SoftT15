﻿import unittest
try:
    from mock import patch
    from TestHelper import TestHelper
    TestHelper.GeneratePythonPath()
    from CatsTooladapter.CATS22.CatsAPIHandler22  import CatsAPIHandler22
    from CatsTooladapter.Exceptions.APICallException  import APICallException
    
    class CatsAPIHandlerUnitTest22(unittest.TestCase):

        @patch.object(CatsAPIHandler22, '__InitializeCatsAPI__')
        def setUp(self, initializeCatsAPI_mock):
            from mock import MagicMock
            self.CatsAPI_Mock = MagicMock()
            self.catsAPIhandler = CatsAPIHandler22(self.CatsAPI_Mock)

        def SetConnectionState(self, isConnected):
            if (isConnected):
                attributes = {"SetRelay.return_value" : 16, "SetRelay.return_value" : 16}
                self.CatsAPI_Mock.configure_mock(**attributes)
                try:
                    self.catsAPIhandler.ConnectDevice()
                except Exception as e:
                    pass

            else:
                attributes = {"SetRelay.return_value" : 0x25}
                self.CatsAPI_Mock.configure_mock(**attributes)
                self.catsAPIhandler.DisconnectDevice()

        def test_SetPWMOutputChannel(self):
            self.SetConnectionState(1)
            attributes = {"SetPWMOut.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetPWMOutputChannel(0,1000,50)
            attributes = {"SetPWMOut.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetPWMOutputChannel ,0,1000,50)
            self.assertRaises(TypeError,self.catsAPIhandler.SetPWMOutputChannel,1.5,1000,50)
            self.assertRaises(TypeError,self.catsAPIhandler.SetPWMOutputChannel,4,1000,50)
            self.assertRaises(TypeError,self.catsAPIhandler.SetPWMOutputChannel,0,1,50)
            self.assertRaises(TypeError,self.catsAPIhandler.SetPWMOutputChannel,0,11000,50)
            self.assertRaises(TypeError,self.catsAPIhandler.SetPWMOutputChannel,0,1000,-1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetPWMOutputChannel,0,1000,101)

        def test_ConnectDevice(self):
            attributes = {"SetRelay.return_value" : 0x10, "SetRelay.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.ConnectDevice()
            attributes = {"SetRelay.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException, self.catsAPIhandler.ConnectDevice)
            
        def test_DisconnectDevice(self):
            self.catsAPIhandler.DisconnectDevice()
           
        def test_SetDACChannelVoltage(self):
            self.SetConnectionState(1)
            attributes = {"setDACVoltage.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetDACChannelVoltage(0,5.0)
            attributes = {"setDACVoltage.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetDACChannelVoltage,0,5.0)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDACChannelVoltage,1.5,5.0)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDACChannelVoltage,0,"A")

        def test_SetDACChannelValue(self):
            self.SetConnectionState(1)
            attributes = {"SetDACValue.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetDACChannelValue(0,255)
            attributes = {"SetDACValue.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetDACChannelValue,0,255)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDACChannelValue,1.5,255)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDACChannelValue,0,"A")
            self.assertRaises(TypeError,self.catsAPIhandler.SetDACChannelValue,0,4096)

        def test_SetLockChannelDACVoltage(self):
            self.SetConnectionState(1)
            attributes = {"setLockDACVoltage.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetLockChannelDACVoltage(5.0,5.0)
            attributes = {"setLockDACVoltage.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetLockChannelDACVoltage,5.0,5.0)
            self.assertRaises(TypeError,self.catsAPIhandler.SetLockChannelDACVoltage,-1,5.0)
            self.assertRaises(TypeError,self.catsAPIhandler.SetLockChannelDACVoltage,5.0,11.0)
            self.assertRaises(TypeError,self.catsAPIhandler.SetLockChannelDACVoltage,0,"A")

        def test_SetLockChannelDACValue(self):
            self.SetConnectionState(1)
            attributes = {"setLockDACValue.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetLockChannelDACValue(255,0)
            attributes = {"setLockDACValue.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetLockChannelDACValue,255,255)
            self.assertRaises(TypeError,self.catsAPIhandler.SetLockChannelDACValue,-1,255)
            self.assertRaises(TypeError,self.catsAPIhandler.SetLockChannelDACValue,255,5000)
            self.assertRaises(TypeError,self.catsAPIhandler.SetLockChannelDACValue,0,"A")

        def test_GetADCChannelVoltagee(self):
            self.SetConnectionState(1)
            attributes = {"getADCVoltage.return_value" : (0x10,5.0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertEqual(self.catsAPIhandler.GetADCChannelVoltage(0),5.0)
            attributes = {"getADCVoltage.return_value" : (0x25,0.0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.GetADCChannelVoltage,0)
            self.assertRaises(TypeError,self.catsAPIhandler.GetADCChannelVoltage,"A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.GetADCChannelVoltage,0)

        def test_GetADCChannelValue(self):
            self.SetConnectionState(1)
            attributes = {"GetADCValue.return_value" : (0x10,255)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertEqual(self.catsAPIhandler.GetADCChannelValue(0),255)
            attributes = {"GetADCValue.return_value" : (0x25,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.GetADCChannelValue,0)
            self.assertRaises(TypeError,self.catsAPIhandler.GetADCChannelValue,"A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.GetADCChannelValue,0)

        def test_SetDigitalOutputChannelStatus(self):
            self.SetConnectionState(1)
            attributes = {"controlDigitalOut.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetDigitalOutputChannelStatus(0,1)
            attributes = {"controlDigitalOut.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetDigitalOutputChannelStatus  ,0,1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDigitalOutputChannelStatus ,1.5,1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDigitalOutputChannelStatus,0,0.5)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDigitalOutputChannelStatus,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDigitalOutputChannelStatus,15,2)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDigitalOutputChannelStatus,0,"A")
            self.assertRaises(TypeError,self.catsAPIhandler.SetDigitalOutputChannelStatus,"A",0)
     
        def test_ConfigureDigitalOutputVoltage(self):
            self.SetConnectionState(1)
            attributes = {"controlDigitalOutVolt.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.ConfigureDigitalOutputVoltage(1)
            attributes = {"controlDigitalOutVolt.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.ConfigureDigitalOutputVoltage ,1)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureDigitalOutputVoltage,-1)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureDigitalOutputVoltage,2)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureDigitalOutputVoltage,"A")

        def test_SetRelayStatus(self):
            self.SetConnectionState(1)
            attributes = {"SetRelay.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetRelayStatus(0,1)
            attributes = {"SetRelay.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetRelayStatus,0,1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetRelayStatus,1.5,1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetRelayStatus,-1,1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetRelayStatus,6,1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetRelayStatus,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.SetRelayStatus,0,-1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetRelayStatus,0,"A")

        def test_GetDigitalInputChannel(self):
            self.SetConnectionState(1)
            attributes = {"GetDigitalInputAll.return_value" : (0x10,1,0,0,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertEqual(self.catsAPIhandler.GetDigitalInputChannel(0),1)
            attributes = {"GetDigitalInputAll.return_value" : (0x25,0,0,0,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.GetDigitalInputChannel,0)
            self.assertRaises(TypeError,self.catsAPIhandler.GetDigitalInputChannel, -1)
            self.assertRaises(TypeError,self.catsAPIhandler.GetDigitalInputChannel, 4)
            self.assertRaises(TypeError,self.catsAPIhandler.GetDigitalInputChannel, "A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.GetDigitalInputChannel,0)

        def test_GetAllDigitalInputChannels(self):
            self.SetConnectionState(1)
            attributes = {"GetDigitalInputAll.return_value" : (0x10,1,0,0,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertEqual(self.catsAPIhandler.GetAllDigitalInputChannels(),(1,0,0,0))
            attributes = {"GetDigitalInputAll.return_value" : (0x25,0,0,0,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.GetAllDigitalInputChannels)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.GetAllDigitalInputChannels)

        def test_ConfigureDigitalInputChannel(self):
            self.SetConnectionState(1)
            attributes = {"GetDigitalInput.return_value" : (0x10,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.ConfigureDigitalInputChannel(0,0)
            attributes = {"GetDigitalInput.return_value" : (0x25,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.ConfigureDigitalInputChannel,0,0)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureDigitalInputChannel, -1, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureDigitalInputChannel, 4, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureDigitalInputChannel, "A",0)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureDigitalInputChannel, 0,-1)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureDigitalInputChannel, 0,3)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureDigitalInputChannel, 0,"A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.ConfigureDigitalInputChannel, 0,0)

        def test_ConfigureAllDigitalInputChannels(self):
            self.SetConnectionState(1)
            attributes = {"GetDigitalInput.return_value" : (0x10,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.ConfigureAllDigitalInputChannels(0)
            attributes = {"GetDigitalInput.return_value" : (0x25,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.ConfigureAllDigitalInputChannels,0)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureAllDigitalInputChannels, -1)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureAllDigitalInputChannels, 3)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureAllDigitalInputChannels, "A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.ConfigureAllDigitalInputChannels, 0)
        '''
        
'''
        def test_ControlPWMOutputVoltage(self):
            self.SetConnectionState(1)
            attributes = {"ChangePWMOutVoltage.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.ConfigurePWMOutputVoltage(5)
            self.catsAPIhandler.ConfigurePWMOutputVoltage(12)
            attributes = {"ChangePWMOutVoltage.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.ConfigurePWMOutputVoltage,5)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigurePWMOutputVoltage, 1)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigurePWMOutputVoltage,6)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigurePWMOutputVoltage,"A")

        def test_ConfigurePWMInputChannel(self):
            self.SetConnectionState(1)
            attributes = {"configurePWMinVolt.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.ConfigurePWMInputChannel(0,0)
            self.catsAPIhandler.ConfigurePWMInputChannel(0,1)
            self.catsAPIhandler.ConfigurePWMInputChannel(0,2)
            attributes = {"configurePWMinVolt.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.ConfigurePWMInputChannel, 0,0)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigurePWMInputChannel, 0,-1)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigurePWMInputChannel, 0, 3)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigurePWMInputChannel, 0, "A")
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigurePWMInputChannel, -1, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigurePWMInputChannel, 4, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigurePWMInputChannel, "A", 0)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.ConfigurePWMInputChannel,0,0)

        def test_ConfigureAllPWMInputs(self):
            self.SetConnectionState(1)
            attributes = {"configurePWMinVolt.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.ConfigureAllPWMInputChannels(0)
            self.catsAPIhandler.ConfigureAllPWMInputChannels(1)
            self.catsAPIhandler.ConfigureAllPWMInputChannels(2)
            attributes = {"configurePWMinVolt.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.ConfigureAllPWMInputChannels, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureAllPWMInputChannels, -1)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureAllPWMInputChannels, 4)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureAllPWMInputChannels, "A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.ConfigureAllPWMInputChannels, 0)
     
        def test_GetPWMInputChannel(self):
            self.SetConnectionState(1)
            attributes = {"ReadPWMIn.return_value" : (0x10,1000,50)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertEqual(self.catsAPIhandler.GetPWMInputChannel(0)[0],1000)
            self.assertEqual(self.catsAPIhandler.GetPWMInputChannel(0)[1],50)
            self.assertEqual(self.catsAPIhandler.GetPWMInputChannel(3)[0],1000)
            self.assertEqual(self.catsAPIhandler.GetPWMInputChannel(3)[1],50)
            attributes = {"ReadPWMIn.return_value" : (0x25,0,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.GetPWMInputChannel, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.GetPWMInputChannel, -1)
            self.assertRaises(TypeError,self.catsAPIhandler.GetPWMInputChannel, 4)
            self.assertRaises(TypeError,self.catsAPIhandler.GetPWMInputChannel, "A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.GetPWMInputChannel, 0)

        def test_GetUBDPowerValuee(self):
            self.SetConnectionState(1)
            attributes = {"MonitorPower.return_value" : (0x10,512)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertEqual(self.catsAPIhandler.GetUBDValue(), 512)
            attributes = {"MonitorPower.return_value" : (0x25,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.GetUBDValue)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.GetUBDValue)

        def test_GetUBDVoltage(self):
            self.SetConnectionState(1)
            attributes = {"monitorPowervoltage.return_value" : (0x10,36)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertEqual(self.catsAPIhandler.GetUBDVoltage(), 36)
            attributes = {"monitorPowervoltage.return_value" : (0x25,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.GetUBDVoltage)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.GetUBDVoltage)

        def test_ResetDevice(self):
            self.SetConnectionState(1)
            attributes = {"ResetHardware.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.ResetDevice()
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.ResetDevice)

        def test_ConfigureMiscellaneousChannel(self):
            self.SetConnectionState(1)
            attributes = {"ConfigureMiscellaneous.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.ConfigureMiscellaneousChannel(0,0)
            self.catsAPIhandler.ConfigureMiscellaneousChannel(1,1)
            attributes = {"ConfigureMiscellaneous.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.ConfigureMiscellaneousChannel, 0,0)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureMiscellaneousChannel, 0,-1)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureMiscellaneousChannel, 0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureMiscellaneousChannel, 0,"A")
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureMiscellaneousChannel, -1,0)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureMiscellaneousChannel, 3,0)
            self.assertRaises(TypeError,self.catsAPIhandler.ConfigureMiscellaneousChannel, "A",0)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.ConfigureMiscellaneousChannel, 0,0)

        def test_GetAllMiscellaneousChannels(self):
            self.SetConnectionState(1)
            attributes = {"ReadMiscellaneousAll.return_value" : (0x10, 1, 0, 1)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            result = self.catsAPIhandler.GetAllMiscellaneousChannels()
            self.assertEqual(result[0],1)
            self.assertEqual(result[1],0)
            self.assertEqual(result[2],1)
            attributes = {"ReadMiscellaneousAll.return_value" : (0x25,0,0,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.GetAllMiscellaneousChannels)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.GetAllMiscellaneousChannels)
        
        def test_GetMiscellaneousChannel(self):
            self.SetConnectionState(1)
            attributes = {"ReadMiscellaneousAll.return_value" : (0x10, 1, 0, 1)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertEqual(self.catsAPIhandler.GetMiscellaneousChannel(0),1)
            attributes = {"ReadMiscellaneousAll.return_value" : (0x25,0,0,0)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.GetMiscellaneousChannel, 1)
            self.assertRaises(TypeError,self.catsAPIhandler.GetMiscellaneousChannel, -1)
            self.assertRaises(TypeError,self.catsAPIhandler.GetMiscellaneousChannel, 3)
            self.assertRaises(TypeError,self.catsAPIhandler.GetMiscellaneousChannel, "A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.GetMiscellaneousChannel, 0)

        def test_SetEngineSpeed(self):
            self.SetConnectionState(1)
            attributes = {"ChangeESMRPM.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetEngineSpeed(3500)
            attributes = {"ChangeESMRPM.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetEngineSpeed, 1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetEngineSpeed, -1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetEngineSpeed, 8000)
            self.assertRaises(TypeError,self.catsAPIhandler.SetEngineSpeed, "A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.SetEngineSpeed, 0)

        def test_SetCamPhase(self):
            self.SetConnectionState(1)
            attributes = {"setCAMPhase.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetCamPhase(1, 0)
            attributes = {"setCAMPhase.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetCamPhase, 1, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCamPhase, 1, -190)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCamPhase, 1, 190)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCamPhase, 1, "A")
            self.assertRaises(TypeError,self.catsAPIhandler.SetCamPhase, -1, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCamPhase, 5, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCamPhase, "A", 0)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.SetCamPhase, 1, 0)

        def test_SelectCrankPattern(self):
            self.SetConnectionState(1)
            attributes = {"selectESMPattern.return_value" : (0x10,"00-01-00")}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SelectCrankPattern(1)
            attributes = {"selectESMPattern.return_value" : (0x25,"00-01-00")}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SelectCrankPattern, 1)
            self.assertRaises(TypeError,self.catsAPIhandler.SelectCrankPattern, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.SelectCrankPattern, 7)
            self.assertRaises(TypeError,self.catsAPIhandler.SelectCrankPattern, "A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.SelectCrankPattern, 1)

        def test_SetCrankMode(self):
            self.SetConnectionState(1)
            attributes = {"SetCrankType.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetCrankMode(1)
            attributes = {"SetCrankType.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetCrankMode, 1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCrankMode, -1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCrankMode, 3)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCrankMode, "A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.SetCrankMode, 1)

        def test_SetCrankDifferentialVoltage(self):
            self.SetConnectionState(1)
            attributes = {"SetCrankDifferentialVoltage.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetCrankDifferentialVoltage(10)
            self.catsAPIhandler.SetCrankDifferentialVoltage(0)
            attributes = {"SetCrankDifferentialVoltage.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetCrankDifferentialVoltage, 10)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCrankDifferentialVoltage, -1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCrankDifferentialVoltage, 11)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCrankDifferentialVoltage, "A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.SetCrankDifferentialVoltage, 10)

        def test_SetCrankSingleVoltage(self):
            self.SetConnectionState(1)
            attributes = {"ChangeESMVoltage.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetCrankSingleVoltage(10)
            self.catsAPIhandler.SetCrankSingleVoltage(0)
            attributes = {"ChangeESMVoltage.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetCrankSingleVoltage, 10)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCrankSingleVoltage, -1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCrankSingleVoltage, 11)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCrankSingleVoltage, "A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.SetCrankSingleVoltage, 10)

        def test_SelectCamPattern(self):
            self.SetConnectionState(1)
            attributes = {"SelectCAMPattern.return_value" : (0x10,"00-00-00")}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SelectCamPattern(1)
            attributes = {"SelectCAMPattern.return_value" : (0x25,"00-00-00")}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SelectCamPattern, 1)
            self.assertRaises(TypeError,self.catsAPIhandler.SelectCamPattern, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.SelectCamPattern, 7)
            self.assertRaises(TypeError,self.catsAPIhandler.SelectCamPattern, "A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.SelectCamPattern, 1)

        def test_SetCamMode(self):
            self.SetConnectionState(1)
            attributes = {"SetCAMType.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetCamMode(1,1)
            attributes = {"SetCAMType.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetCamMode, 1,1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCamMode, 1,-1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCamMode, 1,3)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCamMode, 1,"A")
            self.assertRaises(TypeError,self.catsAPIhandler.SetCamMode, -1,1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetCamMode, 5,1)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.SetCamMode,1, 1)

        def test_SetDG23iMode(self):
            self.SetConnectionState(1)
            attributes = {"SetDG23iMode.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.SetDG23iMode(1,0)
            self.catsAPIhandler.SetDG23iMode(0,0)
            self.catsAPIhandler.SetDG23iMode(1,1)
            self.catsAPIhandler.SetDG23iMode(1,0)
            attributes = {"SetDG23iMode.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.SetDG23iMode, 0, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDG23iMode, -1, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDG23iMode, 2, 0)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDG23iMode, 0, -1)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDG23iMode, 0, 2)
            self.assertRaises(TypeError,self.catsAPIhandler.SetDG23iMode, 0, "A")
            self.assertRaises(TypeError,self.catsAPIhandler.SetDG23iMode, "A", 0)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.SetDG23iMode, 0,0)

        def test_GetFirmwareVersion(self):
            self.SetConnectionState(1)
            attributes = {"GetFirmwareVersion.return_value" : (0x10,"V0.0")}
            self.CatsAPI_Mock.configure_mock(**attributes)
            result = self.catsAPIhandler.GetFirmwareVersion()
            self.assertTrue(result, "V0.0")
            attributes = {"GetFirmwareVersion.return_value" : (0x25,"")}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.GetFirmwareVersion)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.GetFirmwareVersion)

        def test_StartRPMRamp(self):
            self.SetConnectionState(1)
            attributes = {"StartESMRamp.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.catsAPIhandler.StartRPMRamp(0,7500,10,0)
            self.catsAPIhandler.StartRPMRamp(0,7500,10,2)
            attributes = {"StartESMRamp.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.StartRPMRamp,0,7500,10,0)
            self.assertRaises(TypeError,self.catsAPIhandler.StartRPMRamp, -1,7500,10,0)
            self.assertRaises(TypeError,self.catsAPIhandler.StartRPMRamp, 10000,7500,10,0)
            self.assertRaises(TypeError,self.catsAPIhandler.StartRPMRamp, 0,-1,10,0)
            self.assertRaises(TypeError,self.catsAPIhandler.StartRPMRamp, 0,10000,10,0)
            self.assertRaises(TypeError,self.catsAPIhandler.StartRPMRamp, 7500,7499,10,0)
            self.assertRaises(TypeError,self.catsAPIhandler.StartRPMRamp, 0,7500,-1,0)
            self.assertRaises(TypeError,self.catsAPIhandler.StartRPMRamp, 0,7500,10,-1)
            self.assertRaises(TypeError,self.catsAPIhandler.StartRPMRamp, "A",7500,10,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartRPMRamp, 0,"A",10,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartRPMRamp, 0,7500,"A",2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartRPMRamp, 0,7500,10,"A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.StartRPMRamp,0,7500,10,0)
        
        def test_GetRPM(self):
            self.SetConnectionState(1)
            attributes = {"PingRPM.return_value" : (0x10,1000)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            result = self.catsAPIhandler.GetRPM()
            self.assertTrue(result, 1000)
            attributes = {"PingRPM.return_value" : (0x25,1000)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.GetRPM)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.GetRPM)

        def test_StopRPMRamp(self):
            self.SetConnectionState(1)
            attributes = {"StopRPMRamp.return_value" : (0x10,1000)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            result = self.catsAPIhandler.StopRPMRamp()
            self.assertTrue(result, 1000)
            attributes = {"StopRPMRamp.return_value" : (0x25,1000)}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.StopRPMRamp)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.StopRPMRamp)

        def test_StartSENTTransimition(self):
            self.SetConnectionState(1)
            attributes = {"startSENTtransmission.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            result = self.catsAPIhandler.StartSENTTransimition(0,[4,0,0,0,0,11],3,0,0,5,1,0,2)
            attributes = {"startSENTtransmission.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,16,[4,0,0,0,0,11],3,0,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,-1,[4,0,0,0,0,11],3,0,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,"A",[4,0,0,0,0,11],3,0,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[16,0,0,0,0,11],3,0,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[-1,0,0,0,0,11],3,0,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,["A",0,0,0,0,11],3,0,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11,0],3,0,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,11],3,0,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],2,0,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],91,0,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],"A",0,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,-1,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,2,0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,"A",0,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,-283,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,923,5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,"A",5,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,4,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,11,1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,"A",1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,5,-1,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,5,2,0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,5,"A",0,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,5,1,-1,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,5,1,2,2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,5,1,"A",2)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,5,1,0,-1)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,5,1,0,5)
            self.assertRaises(TypeError,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,5,1,0,"A")
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.StartSENTTransimition,0,[4,0,0,0,0,11],3,0,0,5,1,0,2)

        def test_StopSENTTransmission(self):
            self.SetConnectionState(1)
            attributes = {"stopSENTtransmission.return_value" : 0x10}
            self.CatsAPI_Mock.configure_mock(**attributes)
            result = self.catsAPIhandler.StopSENTTransmission()
            attributes = {"stopSENTtransmission.return_value" : 0x25}
            self.CatsAPI_Mock.configure_mock(**attributes)
            self.assertRaises(APICallException,self.catsAPIhandler.StopSENTTransmission)
            self.SetConnectionState(0)
            self.assertRaises(APICallException,self.catsAPIhandler.StopSENTTransmission)
            
except:
    pass
######################## Main #########################    
if __name__ == "__main__":		
    suite = unittest.TestLoader().loadTestsFromTestCase(CatsAPIHandlerUnitTest22)
    unittest.TextTestRunner(verbosity=2).run(suite)