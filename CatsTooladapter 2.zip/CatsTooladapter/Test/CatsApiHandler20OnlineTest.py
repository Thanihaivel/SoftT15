﻿import os
import sys
import clr
import unittest
import time
from parameterized import parameterized
try: 
    from TestHelper import TestHelper
    TestHelper.GeneratePythonPath()
    from CatsTooladapter.CATS20.CatsAPIHandler20  import CatsAPIHandler20
    from CatsTooladapter.Exceptions.APICallException  import APICallException      

    class CatsApiHandler20OnlineTest(unittest.TestCase):		
        
        @classmethod
        def setUpClass(cls):
            dllPath = os.path.join(os.path.dirname(os.path.abspath(__file__)),"..\CATS_API\\ClassLibrary_CATS_2_0_2_2")
            print("\n ddlPath: "+dllPath)
            cls.CatsAPIHandler = CatsAPIHandler20(cls.__ConnectCats__(dllPath))
        
        @classmethod  
        def __ConnectCats__(cls, dllPath):
            sys.path.append(os.path.dirname(dllPath))
            clr.AddReference(os.path.basename(dllPath))
            from BridgeLibraryCat2_0_2_2 import BridgeDll
            bridge = BridgeDll()
            param = None
            interfaceTuple = bridge.LoadingDll(param)
            return(interfaceTuple[1])

       
        def setUp(self):
            pass

        def tearDown(self):
            self.CatsAPIHandler.DisconnectDevice()

        def test_ConnectDevice(self):
            self.CatsAPIHandler.DisconnectDevice()
            self.CatsAPIHandler.ConnectDevice()

        #@parameterized.expand([
        #[0, 0, 10, 1],
        #[7, 1, 7, 1],
        #[19, 2, 4, 1]
        #])
        #def test_SetDACChannelVoltage(self, dacChannel, adcChannel, voltage, maxDeviation): # connect DAC0 to ADC0
        #    self.CatsAPIHandler.ConnectDevice()
        #    self.CatsAPIHandler.SetDACChannelVoltage(dacChannel, voltage)
        #    measuredVoltage = self.CatsAPIHandler.GetADCChannelVoltage(adcChannel)
        #    measuredVoltage = self.CatsAPIHandler.GetADCChannelVoltage(adcChannel)
        #    measuredVoltage = self.CatsAPIHandler.GetADCChannelVoltage(adcChannel)
        #    self.assertGreater(measuredVoltage, voltage-maxDeviation/2.0)
        #    self.assertGreater(voltage+maxDeviation/2.0,measuredVoltage)
        
        @parameterized.expand([
        [0],
        [1],
        [2],
        [3],
        ])   
        def test_DigitalInput(self, channel):
            self.CatsAPIHandler.ConnectDevice()
            self.CatsAPIHandler.ConfigureDigitalOutputVoltage(0)
            self.CatsAPIHandler.SetDigitalOutputChannelStatus(channel,1)
            self.CatsAPIHandler.ConfigureDigitalInputChannel(channel,0)
            time.sleep(0.3)
            measurement = self.CatsAPIHandler.GetDigitalInputChannel(channel)
            self.assertEqual(measurement, 1)
            self.CatsAPIHandler.SetDigitalOutputChannelStatus(channel,0)
except:
    pass # scip in ECU-TEST context

if __name__ == "__main__":		
	suite = unittest.TestLoader().loadTestsFromTestCase(CatsApiHandler20OnlineTest)
	unittest.TextTestRunner(verbosity=2).run(suite)

