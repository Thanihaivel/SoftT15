﻿import os
import sys
import unittest


class TestHelper(unittest.TestCase):
    
    @staticmethod    
    def GeneratePythonPath():
        currentWorkingDirectory = os.getcwd()
        sys.path.append(currentWorkingDirectory[:currentWorkingDirectory.rfind('\\Utilities')]+"\\Utilities")
        from CatsTooladapter.PythonPathGenerator import PythonPathGenerator
        generator = PythonPathGenerator()
        generator.GeneratePythonPath()


