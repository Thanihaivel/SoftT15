﻿try:
try:
    import os
    import sys
    import clr
    import unittest
    from parameterized import parameterized
    import time
    from TestHelper import TestHelper
    TestHelper.GeneratePythonPath()
    from CatsTooladapter.CATS22.CatsAPIHandler22  import CatsAPIHandler22
    from CatsTooladapter.Exceptions.APICallException  import APICallException

    class CatsAPIHandler22OnlineUnitTest(unittest.TestCase):		
        
        @classmethod
        def setUpClass(cls):
            dllPath = os.path.join(os.path.dirname(os.path.abspath(__file__)),"..\CATS_API\\ClassLibrary_CATS_2_0_2_2")
            print("\n ddlPath: "+dllPath)
            cls.CatsAPIHandler = CatsAPIHandler22(cls.__ConnectCats__(dllPath))
            
        
        def setUp(self):
            pass

        @classmethod  
        def __ConnectCats__(cls, dllPath):
            sys.path.append(os.path.dirname(dllPath))
            clr.AddReference(os.path.basename(dllPath))
            from BridgeLibraryCat2_0_2_2 import BridgeDll
            bridge = BridgeDll()
            param = None
            interfaceTuple = bridge.LoadingDll(param)
            return(interfaceTuple[1])
         
        @parameterized.expand([
        [0, 0, 10, 1],
        [7, 1, 7, 1],
        [19, 2, 4, 1]
        ])
        def test_SetDACChannelVoltage(self, dacChannel, adcChannel, voltage, maxDeviation): # connect DAC0 to ADC0
           self.CatsAPIHandler.ConnectDevice()
           self.CatsAPIHandler.SetDACChannelVoltage(dacChannel, voltage)
           measuredVoltage = self.CatsAPIHandler.GetADCChannelVoltage(adcChannel)
           measuredVoltage = self.CatsAPIHandler.GetADCChannelVoltage(adcChannel)
           measuredVoltage = self.CatsAPIHandler.GetADCChannelVoltage(adcChannel)
           self.assertGreater(measuredVoltage, voltage-maxDeviation/2.0)
           self.assertGreater(voltage+maxDeviation/2.0,measuredVoltage)
        
        def test_SetRelayStatus(self): # connect DAC0 to ADC0
           self.CatsAPIHandler.ConnectDevice()
           self.CatsAPIHandler.SetRelayStatus(0,0)
           self.CatsAPIHandler.SetRelayStatus(0,1)
           self.CatsAPIHandler.SetRelayStatus(0,0)
           self.CatsAPIHandler.SetRelayStatus(1,0)
           self.CatsAPIHandler.SetRelayStatus(1,1)
           self.CatsAPIHandler.SetRelayStatus(1,0)
           self.CatsAPIHandler.SetRelayStatus(2,0)
           self.CatsAPIHandler.SetRelayStatus(2,1)
           self.CatsAPIHandler.SetRelayStatus(2,0)
           self.CatsAPIHandler.SetRelayStatus(3,0)
           self.CatsAPIHandler.SetRelayStatus(3,1)
           self.CatsAPIHandler.SetRelayStatus(3,0)
           self.CatsAPIHandler.SetRelayStatus(4,0)
           self.CatsAPIHandler.SetRelayStatus(4,1)
           self.CatsAPIHandler.SetRelayStatus(4,0)
           self.assertRaises(Exception,self.CatsAPIHandler.SetRelayStatus,5,0)

        def test_connectdevice(self):
           self.CatsAPIHandler.ConnectDevice()
           pass

        @parameterized.expand([
        [0],
        [1],
        [2],
        [4],
        [5]
        ])   
        def test_DigitalInput(self, channel):
           self.CatsAPIHandler.ConnectDevice()
           self.CatsAPIHandler.ConfigureDigitalOutputVoltage(0)
           self.CatsAPIHandler.SetDigitalOutputChannelStatus(channel,1)
           self.CatsAPIHandler.ConfigureDigitalInputChannel(channel,0)
           measurement = self.CatsAPIHandler.GetDigitalInputChannel(channel)
           self.assertEqual(measurement, 1)
           self.CatsAPIHandler.SetDigitalOutputChannelStatus(channel,0)

        def test_TestIgnitionIn(self): # connect Misc IGN_In to BN2 
           self.CatsAPIHandler.ConnectDevice()
           self.CatsAPIHandler.SetDACChannelVoltage(2, 10)
           self.CatsAPIHandler.ConfigureMiscellaneousChannel(1,1)
           measurement = self.CatsAPIHandler.GetMiscellaneousChannel(1)
           self.assertEqual(measurement, 1)
           self.CatsAPIHandler.SetDACChannelVoltage(2, 0)
           measurement = self.CatsAPIHandler.GetMiscellaneousChannel(1)
           self.assertEqual(measurement, 0)
           self.CatsAPIHandler.SetDACChannelVoltage(2, 10)
           self.CatsAPIHandler.ConfigureMiscellaneousChannel(1,0)
           measurement = self.CatsAPIHandler.GetMiscellaneousChannel(1)
           self.assertEqual(measurement, 1)
           self.CatsAPIHandler.SetDACChannelVoltage(2, 0)
           measurement = self.CatsAPIHandler.GetMiscellaneousChannel(1)
           self.assertEqual(measurement, 0)


        @parameterized.expand([
        [100],
        [125],
        [250],
        [500],
        [666],
        [1000]
        ])  
        def test_testCan(self, datarate): # connect Misc IGN_In to BN2 
           self.CatsAPIHandler.ConnectDevice()
           self.CatsAPIHandler.ConfigureCanModule(1,datarate)
           self.CatsAPIHandler.ConfigureCanModule(2,datarate)
           self.CatsAPIHandler.SendCANmsgcyclic(1,10,0,8,1,10,0xFF,0,0,0,0,0,0,0,1)
           self.CatsAPIHandler.ConfigureCANRxFilter(2,1,10,0xFF,0,8)
           result = self.CatsAPIHandler.ReadCANmessagecyclic(2,1)
           self.assertEqual(result[1],0)
           self.assertEqual(result[2],0)
           self.assertEqual(result[3],0)
           self.assertEqual(result[4],0)
           self.assertEqual(result[5],0)
           self.assertEqual(result[6],0)
           self.assertEqual(result[7],0)
           self.assertEqual(result[8],1)
            
          
        @parameterized.expand([
        [0, 1000, 50, 900,1100,45,55],
        [1, 5000, 90, 4500,5500,81,99],
        [2, 9500, 10, 8550, 10450, 7,13],
        [4, 7000, 30,6300,7700,27,33]
        ])   
        def test_PWMSignals(self, channelId, frequency, dutyCycle, minSpecFrequency, maxSpecFrequency, minSpecDutyCycle, maxSpecDutyCycle):
           self.CatsAPIHandler.ConnectDevice()
           self.CatsAPIHandler.ConfigurePWMOutputVoltage(12)
           self.CatsAPIHandler.SetPWMOutputChannel(channelId, frequency,dutyCycle)
           self.CatsAPIHandler.ConfigurePWMInputChannel(channelId, 0)
           result = self.CatsAPIHandler.GetPWMInputChannel(channelId)
           self.assertLessEqual(result[0],maxSpecFrequency)
           self.assertGreaterEqual(result[0],minSpecFrequency)
           self.assertLessEqual(result[1],maxSpecDutyCycle)
           self.assertGreaterEqual(result[1],minSpecDutyCycle)

        @parameterized.expand([
        [1000, 50, 900,1100,45,55],
        [5000, 90, 4500,5500,81,99],
        [9500, 10, 8550, 10450, 7,13],
        [7000, 30,6300,7700,27,33]
        ])  
        def test_HBridgeSignals_Channel1(self, frequency, dutycycle, minSpecFrequency, maxSpecFrequency, minSpecDutyCycle, maxSpecDutyCycle):
            self.CatsAPIHandler.ConnectDevice()
            self.CatsAPIHandler.SetHBridgeOut(0,frequency, dutycycle)
            self.CatsAPIHandler.ConfigurePWMOutputVoltage(12)
            self.CatsAPIHandler.ConfigurePWMInputChannel(3, 0)
            result = self.CatsAPIHandler.GetPWMInputChannel(3)
            self.assertLessEqual(result[0],maxSpecFrequency)
            self.assertGreaterEqual(result[0],minSpecFrequency)
            self.assertLessEqual(result[1],maxSpecDutyCycle)
            self.assertGreaterEqual(result[1],minSpecDutyCycle)
        
        def test_HBridgeSignals_Stop(self):
           self.CatsAPIHandler.ConnectDevice()
           self.CatsAPIHandler.SetHBridgeOut(0,1000, 50)
           self.CatsAPIHandler.ConfigurePWMOutputVoltage(12)
           self.CatsAPIHandler.ConfigurePWMInputChannel(3, 0)
           result = self.CatsAPIHandler.GetPWMInputChannel(3)
           self.assertLessEqual(result[0],1100)
           self.assertGreaterEqual(result[0],900)
           self.CatsAPIHandler.StopHBridgeOut(0)
           result = self.CatsAPIHandler.GetPWMInputChannel(3)
           self.assertLessEqual(result[0],0)

        def test_ResetTest(self):
           self.CatsAPIHandler.ConnectDevice()
           #self.CatsAPIHandler.ResetDevice()
           #time.sleep(2)
           #self.CatsAPIHandler.ConnectDevice()
           self.CatsAPIHandler.SetDACChannelVoltage(0, 5)
           measuredVoltage = self.CatsAPIHandler.GetADCChannelVoltage(0)
           measuredVoltage = self.CatsAPIHandler.GetADCChannelVoltage(0)
           measuredVoltage = self.CatsAPIHandler.GetADCChannelVoltage(0)
           self.assertGreater(measuredVoltage, 4)
           self.assertGreater(6,measuredVoltage)
        
        @parameterized.expand([
        [80],
        [70],
        [30],
        [20]
        ]) 
        def test_HBridgeSignals_Channel2(self, dutycycle):
            self.CatsAPIHandler.ConnectDevice()
            powerSupplyVoltage = self.CatsAPIHandler.MonitorPowerSupplyVoltage()
            resultVoltage = powerSupplyVoltage/50*dutycycle-powerSupplyVoltage
            self.CatsAPIHandler.ConfigurePWMOutputVoltage(12) 
            self.CatsAPIHandler.SetHBridgeOut(1,8000, dutycycle)
            measuredVoltage = 0
            for nMeasurement in range(1,100):
                measuredVoltage += self.CatsAPIHandler.GetADCChannelVoltage(3)
            measuredVoltage /= 100
            if(dutycycle>=50):
                self.assertGreaterEqual(measuredVoltage,resultVoltage*0.7, resultVoltage*1.3)
            else:
                self.assertGreaterEqual(measuredVoltage,resultVoltage*1.3, resultVoltage*0.7)
        
        def test_testSentTransmition(self): 
           status = 0
           nibbles = [0,0,0,0,0,0]
           clockTick = 3;
           frameLengthType = 0;
           framelength = 0;
           lowpulseLength = 5;
           crcMode = 0;
           polarity = 0; 
           sensorType = 0;
           channel = 1;
           self.CatsAPIHandler.StartSENTTransimition(channel, status, nibbles, clockTick, frameLengthType, framelength, lowpulseLength, crcMode, polarity, sensorType)
           self.CatsAPIHandler.StopSENTTransmission()

        def test_ConfigureDigitalInputAll(self):
           self.CatsAPIHandler.ConnectDevice()
           result = self.CatsAPIHandler.ConfigureAllDigitalInputChannels(0)

        def test_ConfigureAllPWMInputChannels(self):
           self.CatsAPIHandler.ConnectDevice()
           result = self.CatsAPIHandler.ConfigureAllPWMInputChannels(0)
        
        def test_DACChannelValue(self):
           self.CatsAPIHandler.ConnectDevice()
           self.CatsAPIHandler.SetDACChannelValue(0,2000)
           result = self.CatsAPIHandler.GetADCChannelValue(0)
           result = self.CatsAPIHandler.GetADCChannelValue(0)
           #result = self.CatsAPIHandler.GetADCChannelValue(0)
           #result = self.CatsAPIHandler.GetADCChannelValue(0)
           self.assertGreater(result,1500)
           self.assertLess(result,2500)

        def test_DACChannelVoltage(self):
           self.CatsAPIHandler.ConnectDevice()
           self.CatsAPIHandler.SetDACChannelVoltage(0,10)
           result = self.CatsAPIHandler.GetADCChannelVoltage(0)
           result = self.CatsAPIHandler.GetADCChannelVoltage(0)
           #result = self.CatsAPIHandler.GetADCChannelVoltage(0)
           #result = self.CatsAPIHandler.GetADCChannelVoltage(0)
           self.assertGreater(result,9)
           self.assertLess(result,11)

        def test_RpmRamp(self):
            self.CatsAPIHandler.ConnectDevice()
            self.CatsAPIHandler.StartRPMRamp(0,5000,10,10)
            self.CatsAPIHandler.StopRPMRamp()

except:
    pass # scip in ECU-TEST context


if __name__ == "__main__":		
	suite = unittest.TestLoader().loadTestsFromTestCase(CatsAPIHandler22OnlineUnitTest)
	unittest.TextTestRunner(verbosity=2).run(suite)