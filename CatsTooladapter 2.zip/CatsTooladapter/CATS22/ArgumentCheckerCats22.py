﻿import sys
import clr
import os
import sys
import types
import numbers
import time
from System import Double, Decimal, SByte



IsECUTestContext = False
if (str(sys.argv[0])[str(sys.argv[0]).rfind("."):] == ".exe"):
   IsECUTestContext = True

if (IsECUTestContext):
    from user.PLib.System.Logger import Logger, LogLevel
    from user.PLib.System.Constant import Const
    from user.PLib.System.Singleton import Singleton
    import user.PLib.System.Enum as Enum
    from ..Exceptions.APICallException  import APICallException
    from ..ArgumentChecker import ArgumentChecker
else:
    from PLib.System.Logger import Logger, LogLevel
    from PLib.System.Constant import Const
    from PLib.System.Singleton import Singleton
    import PLib.System.Enum as Enum
    from CatsTooladapter.ArgumentChecker import ArgumentChecker
    from CatsTooladapter.Exceptions.APICallException  import APICallException

class ArgumentCheckerCats22(ArgumentChecker):
    """description of class"""
    ChannelType = Enum.enum(DACChannel=0, ADCChannel=1, RelayChannel=2, DigitalChannel=3, MiscChannel=4, EngineSpeedCamChannel=5)

    def __init__(self):
       super(self.__class__,self).__init__()
       self.MAXCHANNELCOUNT = Const({ArgumentCheckerCats22.ChannelType.DACChannel : 20,ArgumentCheckerCats22.ChannelType.ADCChannel :4, ArgumentCheckerCats22.ChannelType.RelayChannel : 5, ArgumentCheckerCats22.ChannelType.DigitalChannel : 8, ArgumentCheckerCats22.ChannelType.MiscChannel : 3, ArgumentCheckerCats22.ChannelType.EngineSpeedCamChannel : 4})
       self.DIGITALOUTPUTVOLTAGESELECTOR = Const([0,1])
       self.ONOFFSTATUS = Const([0,1])
       self.MAXIMUMDACVOLTAGE = Const(10)
       self.MAXIMUMDACVALUE = Const(10000)
       self.REFERENCEVOLTAGESELECTOR = Const([0,1,2])
       self.MAXIMUMPWMFREQUENCY = Const(10000)
       self.MINIMUMPWMFREQUENCY = Const(6)
       self.MAXIMUMDUTYCYCLEPERCENT = Const(100)
       self.PWMOUTPUTVOLTAGESELECTOR = Const([5,12])
       self.MISCELLANEOUSCONFIGURATION = Const([0,1])
       self.MAXENGINESPEED = Const(7500)
       self.MINENGINESPEEDCAMANGLE = Const(-180)
       self.MAXENGINESPEEDCAMANGLE = Const(180)
       self.PATTERNSELECTION = Const([1,2,3,4,5,6])
       self.CRANKCAMMODE = Const([0,1])
       self.MAXIMUMCRANKVOLTAGE = Const(10)
       self.DG23IMODEDIRECTION = Const([0,1])
       self.CANBAUDRATES = Const([100,125,250,500,666,1000])
       self.SENTSTATUS = Const([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15])
       self.SENTNIBBLERANGE = Const([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15])
       self.SENTMINCLOCKTICKS = Const(3)
       self.SENTMAXCLOCKTICKS = Const(90)
       self.SENTFRAMELENGTHTYPE = Const([0,1])
       self.SENTMINFRAMELENGTH = Const(-282)
       self.SENTMAXFRAMELENGTH = Const(922)
       self.SENTLOWPULSELEGNTH = Const([5,6,7,8,9,10])
       self.SENTCRCMODE = Const([0,1])
       self.SENTSIGNALPOLARITY = Const([0,1])
       self.SENTSENSORTYPE = Const([0,1,2,3,4])
       self.SENTNIBBLESCOUNT = Const(6)
       self.CANMESSAGETRANSMITIONINTERVAL = Const([1,255])
       self.CANIDType = Const([0,1])
       self.CANDATALENGTH = Const([1,8])
       self.CANMSGOBJECTRANGE = Const([0x01, 0x0F])
       self.CANDATAPAYLOADRANGE = Const([0,0xFF])
       self.CANCHANNELS = Const([1,2])
       self.HBRIDGECHANNELS = Const([0,1])
       self.HBRIDGEFREQUENCYRANGE = Const([10,10000])
       self.HBRIDGEDUTYCYCLE = Const([0,100])

    def CheckAPICallStatus(self, value, callingMethodName):
        methodName = callingMethodName +": "+ArgumentChecker.__className__ + "."+"CheckAPICallStatus"
        if (value != 0x10):
            errorMessage = methodName+": API returned error code: "+str(value)
            raise APICallException(errorMessage)