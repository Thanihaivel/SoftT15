﻿import sys
import os
import types
import numbers
import time
import clr
from System import Byte, Int16, UInt16, Decimal, Double, Int64, Single

IsECUTestContext = False
if (str(sys.argv[0])[str(sys.argv[0]).rfind("."):] == ".exe"):
   IsECUTestContext = True

if (IsECUTestContext):
    from user.PLib.System.Logger import Logger, LogLevel
    from user.PLib.System.Constant import Const
    from user.PLib.System.Singleton import Singleton
    import user.PLib.System.Enum as Enum
    from ..CatsAPIHandler import CatsAPIHandler
    from ..Exceptions.APICallException  import APICallException
    from ..Exceptions.CatsInitializationException  import CatsInitializationException
    from .ArgumentCheckerCats22 import ArgumentCheckerCats22
else:
    from PLib.System.Logger import Logger, LogLevel
    from PLib.System.Constant import Const
    from PLib.System.Singleton import Singleton
    import PLib.System.Enum as Enum
    from CatsTooladapter.CatsAPIHandler import CatsAPIHandler
    from CatsTooladapter.Exceptions.APICallException  import APICallException
    from CatsTooladapter.Exceptions.CatsInitializationException  import CatsInitializationException
    from CatsTooladapter.CATS22.ArgumentCheckerCats22 import ArgumentCheckerCats22

class CatsAPIHandler22(CatsAPIHandler):
    __className__ = "CatsAPIHandler22"

    def __init__(self, catsInterface, outputWaitTime=0):   
        super(self.__class__,self).__init__(catsInterface, ArgumentCheckerCats22(), outputWaitTime)
        

    def ConnectDevice(self):
       """
            Connect to CATS device
       """
       methodName = CatsAPIHandler22.__className__ + ".ConnectDevice"
       self.__IsConnected__ = False
       returnValue = self.cats.WriteRelayOutput(0,1)
       time.sleep(1)
       returnValue &= self.cats.WriteRelayOutput(0,0)
       self.ArgumentChecker.CheckAPICallStatus(returnValue,methodName)
       time.sleep(self.OutputWaitTime)
       self.__IsConnected__ = True
   
    def DisconnectDevice(self):
        methodName = CatsAPIHandler22.__className__ + ".DisconnectDevice"
        self.__IsConnected__ = False

    def SetPWMOutputChannel(self, channelId, frequency, dutyCycle):
        """
           Sets the given frequency and dutycycle to the given channel
           
           Args:
               channelId : 0-3
               frequency : 6Hz - 10000Hz
               dutyCycle : 0% - 100%
       """
        super(self.__class__,self).SetPWMOutputChannel(channelId, frequency, dutyCycle)
        methodName = CatsAPIHandler22.__className__+".SetPWMOutputChannel"
        errorMessage = methodName+": API-Call WritePWMoutput with channelId: "+str(channelId)+" frequency: "+str(frequency)+" dutyCycle: "+str(dutyCycle)+" failed."
        try:
           #decimalDutyCycle = Decimal.__overloads__[Double](dutyCycle) #not possible for CATS 2.2
           result = self.cats.WritePWMoutput(Byte(channelId), UInt16(frequency), Byte(dutyCycle))
           self.ArgumentChecker.CheckAPICallStatus(result, methodName)
           time.sleep(self.OutputWaitTime)
        except Exception as e:
           errorMessage +=": Failed to WritePWMoutput with channelId: "+str(channelId)+" statusfrequency: "+str(frequency)+" dutyCycle: "+str(dutyCycle)+" Exception: "+str(e)
           Logger().LogError(errorMessage)
           raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WritePWMoutput: Status API-Call: "+str(result))
 

    def ConfigurePWMOutputVoltage(self, voltageSelector):
        #if (voltageSelector == 5):
        #    voltageSelector = 0
        #elif (voltageSelector == 12):
        #        voltageSelector = 1
        #else:
        #    voltageSelector = -1
        super(self.__class__,self).ConfigurePWMOutputVoltage(voltageSelector)

    def GetPWMInputChannel(self, channelId):
        super(self.__class__,self).GetPWMInputChannel(channelId)
        methodName = CatsAPIHandler22.__className__+".GetPWMInputChannel"
        errorMessage = methodName+": API-Call ReadPWMinput with channelId: "+str(channelId)+" failed."
        try:
            result = self.cats.ReadPWMinput(Byte(channelId),Byte(0),Int16(0),Single(0))
            self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to ReadPWMinput with channelId: "+str(channelId)+" Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ReadPWMinput: Status API-Call: "+str(result[0]))
        Logger().LogDebug(methodName+": ReadPWMinput: Frequency: "+str(result[1])+" DutyCycle: "+str(result[2]))
        return(result[2:])
     
    def ConfigureCanModule(self, channel, baudrate):
        methodName = CatsAPIHandler22.__className__+".ConfigureCanModule"
        errorMessage = methodName+": API-Call configureCANmodule with baudrate: "+str(baudrate)+"kbps failed."
        try:
            self.ArgumentChecker.CheckDedicatedRange(baudrate, self.ArgumentChecker.CANBAUDRATES.value,int,methodName)
            self.ArgumentChecker.CheckDedicatedRange(channel, self.ArgumentChecker.CANCHANNELS.value,int,methodName)
            result = self.cats.ConfigureCANmodule(Byte(channel),UInt16(baudrate))
            self.ArgumentChecker.CheckAPICallStatus(result, methodName)
        except Exception as e:
            errorMessage +=": Failed to ConfigureCANmodule with baudrate: "+str(baudrate)+"kbps. Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ConfigureCANmodule: Status API-Call: "+str(result))

    def SendCANmsgcyclic(self, channelId, datarate, idType, datalength, msgObject, msgID, mask, data1, data2, data3, data4, data5, data6, data7, data8):
        methodName = CatsAPIHandler22.__className__+".SendCANmsgcyclic"
        errorMessage = methodName+": API-Call WriteCANmessageCyclic with datarate: "+str(datarate)+"ms idType:"+str(idType)+" datalength:"+str(datalength)+" msgObject:"+str(msgObject)+" msgID: "+str(msgID)+" mask:"+str(mask)+" data1:"+str(data1)+" data2:"+str(data2)+" data3:"+str(data3)+" data4:"+str(data4)+" data5:"+str(data5)+" data6:"+str(data6)+" data7:"+str(data7)+" data8:"+str(data8)+" failed."
        try:
            self.ArgumentChecker.CheckContinuesRange(channelId,self.ArgumentChecker.CANCHANNELS.value[0],self.ArgumentChecker.CANCHANNELS.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(datarate,self.ArgumentChecker.CANMESSAGETRANSMITIONINTERVAL.value[0],self.ArgumentChecker.CANMESSAGETRANSMITIONINTERVAL.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(idType,self.ArgumentChecker.CANIDType.value[0],self.ArgumentChecker.CANIDType.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(datalength,self.ArgumentChecker.CANDATALENGTH.value[0],self.ArgumentChecker.CANDATALENGTH.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(msgObject,self.ArgumentChecker.CANMSGOBJECTRANGE.value[0],self.ArgumentChecker.CANMSGOBJECTRANGE.value[1],int,methodName)
            self.ArgumentChecker.CheckType (msgID,int,methodName)
            self.ArgumentChecker.CheckType (mask,int,methodName)
            self.ArgumentChecker.CheckContinuesRange(data1,self.ArgumentChecker.CANDATAPAYLOADRANGE.value[0],self.ArgumentChecker.CANDATAPAYLOADRANGE.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(data2,self.ArgumentChecker.CANDATAPAYLOADRANGE.value[0],self.ArgumentChecker.CANDATAPAYLOADRANGE.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(data3,self.ArgumentChecker.CANDATAPAYLOADRANGE.value[0],self.ArgumentChecker.CANDATAPAYLOADRANGE.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(data4,self.ArgumentChecker.CANDATAPAYLOADRANGE.value[0],self.ArgumentChecker.CANDATAPAYLOADRANGE.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(data5,self.ArgumentChecker.CANDATAPAYLOADRANGE.value[0],self.ArgumentChecker.CANDATAPAYLOADRANGE.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(data6,self.ArgumentChecker.CANDATAPAYLOADRANGE.value[0],self.ArgumentChecker.CANDATAPAYLOADRANGE.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(data7,self.ArgumentChecker.CANDATAPAYLOADRANGE.value[0],self.ArgumentChecker.CANDATAPAYLOADRANGE.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(data8,self.ArgumentChecker.CANDATAPAYLOADRANGE.value[0],self.ArgumentChecker.CANDATAPAYLOADRANGE.value[1],int,methodName)
            result = self.cats.WriteCANmessageCyclic(Byte(channelId), UInt16(datarate), Byte(idType), Byte(datalength), Byte(msgObject), Int64(msgID), Int64(mask), Byte(data1), Byte(data2), Byte(data3), Byte(data4), Byte(data5), Byte(data6), Byte(data7), Byte(data8))
            #self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to WriteCANmessageCyclic. Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteCANmessageCyclic: Status API-Call: "+str(result))
    
    def ConfigureCANRxFilter(self, channelId, msgObject, msgID, mask, idType, datalength):
        methodName = CatsAPIHandler22.__className__+".ConfigureCANRxFilter"
        errorMessage = methodName+": API-Call WriteCANRxFilterConfiguration with datarate: "+str(channelId)+" msgObject:"+str(msgObject)+" msgID:"+str(msgID)+" mask:"+str(mask)+" idType: "+str(idType)+" datalength:"+str(datalength)+" failed."
        try:
            self.ArgumentChecker.CheckContinuesRange(channelId,self.ArgumentChecker.CANCHANNELS.value[0],self.ArgumentChecker.CANCHANNELS.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(idType,self.ArgumentChecker.CANIDType.value[0],self.ArgumentChecker.CANIDType.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(datalength,self.ArgumentChecker.CANDATALENGTH.value[0],self.ArgumentChecker.CANDATALENGTH.value[1],int,methodName)
            self.ArgumentChecker.CheckContinuesRange(msgObject,self.ArgumentChecker.CANMSGOBJECTRANGE.value[0],self.ArgumentChecker.CANMSGOBJECTRANGE.value[1],int,methodName)
            self.ArgumentChecker.CheckType (msgID,int,methodName)
            self.ArgumentChecker.CheckType (mask,int,methodName)
            result = self.cats.WriteCANRxFilterConfiguration(Byte(channelId), Byte(msgObject), Int64(msgID), Int64(mask), Byte(idType), Byte(datalength))
        except Exception as e:
            errorMessage +=": Failed to WriteCANRxFilterConfiguration. Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": WriteCANRxFilterConfiguration: Status API-Call: "+str(result))

    def ReadCANmessagecyclic(self, channelID, msgObject):
        methodName = CatsAPIHandler22.__className__+".ReadCANmessagecyclic"
        errorMessage = methodName+": API-Call ReadCANRxData with channelID: "+str(channelID)+"ms msgObject:"+str(msgObject)+" failed."
        try:
             self.ArgumentChecker.CheckContinuesRange(msgObject,self.ArgumentChecker.CANMSGOBJECTRANGE.value[0],self.ArgumentChecker.CANMSGOBJECTRANGE.value[1],int,methodName)
             result = self.cats.ReadCANRxData(Byte(channelID), Byte(msgObject), Int64(0), Byte(0), Byte(0), Byte(0), Byte(0), Byte(0), Byte(0), Byte(0), Byte(0))
            #self.ArgumentChecker.CheckAPICallStatus(result[0], methodName)
        except Exception as e:
            errorMessage +=": Failed to ReadCANRxData. Exception: "+str(e)
            Logger().LogError(errorMessage)
            raise APICallException(errorMessage)
        Logger().LogDebug(methodName+": ReadCANRxData: Status API-Call: "+str(result))
        return result[1:]

    def GetDigitalInputAll(self):
        return (self.cats.ReadDigitalInputAll(Byte(0),Byte(0),Byte(0),Byte(0),Byte(0),Byte(0),Byte(0),Byte(0)))

